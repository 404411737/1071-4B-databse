<?php session_start();
if(!isset($_SESSION['username'])){
 echo "抱歉 您尚未登入 如要繼續使用請先登入!";
 header("refresh:2;url=page1v3.html");  //轉址
 exit(); }//不執行之後的程式碼?>
<?php
    /*error_reporting(E_ALL ^ E_DEPRECATED);
    $dramaname1=$_GET['dramastore'];
     include("mysql_connect.inc.php");
     $sql = "SELECT * FROM dramaticule where dramaname = '$dramaname1'";
     $result = mysql_query($sql);
      while($row = mysql_fetch_array($result)){
                            $str = $row['drama'];
                        }    
    /*include("mysql_connect.inc.php");
    //mysqli_query($link, 'SET CHARACTER SET utf8');
    //mysqli_query($link,  "SET collation_connection = 'utf8_general_ci'");
    $dramaname1=$_GET['dramastore'];

    $result=
    $sql = "UPDATE dramaticule SET drama = '$_POST['editor']' WHERE dramaname = '$dramaname1'";
        if(mysql_query($sql))
        {
            echo "ADDED INTO DB";
        }
        else
        {
            echo "ERROR WHILE INSERTING";
            //$_SESSION['editor'];
        }
   
    if(isset($_POST['editor']))
    {
        $text = $_POST['editor'];
        //連到database
        //$con = mysqli_connect('localhost','root','1234','mydb') or die("ERROR");
        //插進session
        //$_SESSION['editor'] = $text;
        //插入data 不過後來用SESSION了
        //$query = mysqli_query($con,"INSERT INTO content (content) VALUES ('$text')");
       // $sql = mysqli_query($con,"UPDATE dramaticule SET drama = '$text' WHERE dramaname = '$dramaname1'");
        $sql = "UPDATE dramaticule SET drama = '$text' WHERE dramaname = '$dramaname1'";
        if($query)
        {
            echo "ADDED INTO DB";
        }
        else
        {
            echo "ERROR WHILE INSERTING";
            //$_SESSION['editor'];
        }
    }*/


?>
    <html>
		<head>
            <link href="semantic/semantic.min.css" rel="stylesheet" type="text/css">
            <script src="semantic/jquery-3.2.1.min.js"></script>
            <script src="semantic/semantic.min.js"></script>
            <meta charset="utf-8">    
            <title>實驗小劇場</title>
            <style>
                .HEADER{
                    position:fixed;
                    height:10%;
                    width:100%;
                    background-color:#3E5C76;
                    display:flex;
                    align-items:center;
                    justify-content:flex-end;
                    float:inherit;
                    top:0;
                    right:0;
                    
                }
                .CONTAINER{
                    position:absolute;
                    height:85%;
                    width:100%;
                    background-color:#FFFFFF;
                    text-align:center;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    top:10%;
                    right:0;
                }
                .FOOTER{
                    position:fixed;
                    height:5%;
                    width:100%;
                    background-color:#8D99AE;   
                    text-align:center;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    float:inherit;
                    bottom:0;
                    right:0;
                }
                #testbar{
                    font-family:Microsoft JhengHei;
                    color:#FFFFFF;
                    display:none;
                }
            </style>
            <script src="ckeditor/ckeditor.js"></script>
            <script type="text/javascript">
                var SP = jQuery.noConflict();
                    function hideFuction(){
                        var element = document.getElementById('testbar');
                        style = window.getComputedStyle(element);
                        if(style.display=="none"){
                            SP("#testbar").css("display","inline");
                            SP(".CONTAINER").css("height","70%");
                            SP(".FOOTER").css("height","20%");
                        }else{
                            SP("#testbar").css("display","none");
                            SP(".CONTAINER").css("height","85%");
                            SP(".FOOTER").css("height","5%");
                        }
                    }
            </script>
            
		</head>       
		<body>
            <div class ="HEADER">
                <div class="ui circular animated fade button" tabindex="0">
                <div class="visible content">Username</div>
                <div class="hidden content" onclick="self.location.href='logout.php'" >LOGOUT</div>
                </div>
            </div>
            <div class ="CONTAINER">
                <form action="updategroundname.php" method="post" >
                <textarea class="updatename" name="groundname">
                    <?php  
                   error_reporting(E_ALL ^ E_DEPRECATED);

                   //include("mysql_connect.inc.php");
                   $db_server = "localhost";
                    $db_name = "mydb";
                    $db_user = "root";
                    $db_passwd = "1234";
                    $con = mysql_connect($db_server, $db_user, $db_passwd);
                    mysql_query("SET NAMES 'utf8'");
                    mysql_select_db($db_name);
                   $gnumber=$_GET['groundstore'];
                   $_SESSION["gnumber"]=$gnumber;
                   $dramaname3=$_SESSION["dramaname"];
                   
                   $sql = "SELECT * FROM $dramaname3 where groundnumber = '$gnumber'";
                   $result = mysql_query($sql);
                   while($row = mysql_fetch_array($result)){
                            $str = $row['groundname'];
                            echo $str;
                            //$_SESSION["gname"] = $row['groundname'];   
                        }    
                         ?>
                </textarea>
                <input type="submit" id="button" value="更改場景名稱">
                </form>
                <form action="updateground.php" method = "post">
                    <textarea class ="ckeditor" name="editor"  width=800px height=400px> <?php  
                   error_reporting(E_ALL ^ E_DEPRECATED);

                   include("mysql_connect.inc.php");
                   $gnumber=$_GET['groundstore'];
                   $_SESSION["gnumber"]=$gnumber;
                   $dramaname3=$_SESSION["dramaname"];
                   
                   $sql = "SELECT * FROM $dramaname3 where groundnumber = '$gnumber'";
                   $result = mysql_query($sql);
                   while($row = mysql_fetch_array($result)){
                            $str = $row['grounddrama'];
                            echo $str;
                            //$_SESSION["gname"] = $row['groundname'];   
                        }     ?> 
                    </textarea>
                    <input type="submit" id="button" value="post">
                   
                </form>
            </div>
            <div class ="FOOTER">
                <div class="ui circular button" tabindex="0" onclick="hideFuction()">SWICTH</div>
                <p id ="testbar">TEST</p>
            </div>
        </body>
</html>