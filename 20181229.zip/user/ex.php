<html>
<body>

<form action="upload.php" method="post" enctype="multipart/form-data">
檔案名稱:<input type="file" name="file" id="file" /><br />
<input type="submit" name="submit" value="上傳檔案" />
</form>

</body>
</html>