const db = require('../util/database');

module.exports = class Video {

    constructor(vID,vName, vDirector,vRating,vRank,vComment,vPrice,vDate) {
        this.vID = vID;
        this.vName = vName;
        this. vDirector =  vDirector;
        this.vRating = vRating;
        this.vRank = vRank;
        this.vComment = vComment;
        this.vPrice = vPrice;
        this.vDate = vDate;
    }

    //READ
    static fetchAll() {
        return db.execute('SELECT * FROM vlist');
    }

    //ADD
    static add(req, res) {
        return db.execute(
          'INSERT INTO vlist (vName, vDirector,vRating,vRank,vComment,vPrice,vDate) VALUES (?,?,?,?,?,?,?)',
          [req.body.vName, req.body.vDirector, req.body.vRating, req.body.vRank, req.body.vComment, req.body.vPrice, req.body.vDate]
        );
    }

    //DELETE
    static deleteById(vID) {
        return db.execute(
        'DELETE FROM vlist WHERE vID = ?', [vID]
        );
    }

    //UPDATE
    static updateById(req, res) {
        this.vID = req.body.vID;
        this.vName = req.body.vName;
        this. vDirector =  req.body.vDirector;
        this.vRating = req.body.vRating;
        this.vRank = req.body.vRank;
        this.vComment = req.body.vComment;
        this.vPrice = req.body.vPrice;
        this.vDate = req.body.vDate

        return db.execute(
          'UPDATE vlist SET vName = ?, vDirector = ?, vRating = ?, vRank = ?, vComment = ?, vPrice = ? ,vDate = ?　WHERE vID = ?', [vID,vName, vDirector,vRating,vRank,vComment,vPrice,vDate]
        );
      }
}