const db = require('../util/database');

module.exports = class Account {

    constructor(uID,uName,uEmail,uPassword,uPhone) {
      this.uID = uID;
      this.uName = uName;
      this.uEmail = uEmail;
      this.uPassword = uPassword;
      this.uPhone = uPhone;
    }

    // READ
    static fetchAll() {
        return db.execute('SELECT * FROM users');
    }

    //ADD
    static add(req, res) {
        return db.execute(
          'INSERT INTO users (uID,uName,uEmail,uPassword,uPhone) VALUES (?,?,?,?,?)',
          [req.body.uID, req.body.uName, req.body.uEmail, req.body.uPassword, req.body.uPhone]
        );
    }

    //DELETE
    static deleteById(uID) {
        return db.execute(
        'DELETE FROM users WHERE uID = ?', [uID]
        );
    }

    //UPDATE
    static updateById(req, res) {
        this.uID = req.body.uID;
        this.uName = req.body.uName;
        this.uEmail = req.body.uEmail;
        this.uPassword = req.body.uPassword;
        this.uPhone = req.body.uPhone;

        return db.execute(
          'UPDATE users SET uID = ?, uName = ?, uEmail = ?, uPassword = ?, uPhone = ? WHERE uID = ?', [uID,uName,uEmail,uPassword,uPhone]
        );
      }
}