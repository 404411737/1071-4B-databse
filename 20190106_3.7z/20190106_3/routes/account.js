var express = require('express');
var router = express.Router();

const accountController = require('../controllers/account');

router.get('/',accountController.getAccount);
router.get('/add',accountController.postAddAccount);
router.get('/delete',accountController.getDeleteAccount);
router.get('/update',accountController.postUpdateAccount);

module.exports = router;