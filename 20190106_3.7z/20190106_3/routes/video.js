var express = require('express');
var router = express.Router();

const videoController = require('../controllers/video');

router.get('/',videoController.getVideo);
router.get('/add',videoController.postAddVideo);
router.get('/delete',videoController.getDeleteVideo);
router.get('/update',videoController.postUpdateVideo);

module.exports = router;