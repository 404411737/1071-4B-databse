const moment = require('moment');

const Record = require('../models/record');

//READ
exports.getRecord = (req, res, next) => {
    Record.fetchAll()
        .then(([rows]) => {
            //console.log(JSON.stringify(rows));
            res.send(JSON.stringify(rows));
            //res.render('record', {
                // data: rows,
                //title: 'List',
            //});
        })
        .catch(err => console.log(err));
};

//ADD
exports.postAddRecord = (req, res, next) => {
    Record.add(req, res)
        .then(([rows]) => {
            res.redirect('/record');
        })
        .catch(err => console.log(err));
};

//DELETE
exports.getDeleteRecord = (req, res, next) => {
    Record.deleteById(req.query.No)
        .then(([rows]) => {
            res.redirect('/record');
        })
    .catch();
};

//UPDATE
exports.postUpdateRecord = (req, res, next) => {
    Record.updateById(req, res)
        .then(([rows]) => {
            res.redirect('/record');
        })
        .catch(err => console.log(err));
};