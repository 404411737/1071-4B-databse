const moment = require('moment');

const Video = require('../models/video');

//READ
exports.getVideo = (req, res, next) => {
    Video.fetchAll()
        .then(([rows]) => {
            //console.log(JSON.stringify(rows));
            //res.send(JSON.stringify(rows));
            res.render('video', {
                vData : rows
            });
        })
        .catch(err => console.log(err));
};

//ADD
exports.postAddVideo = (req, res, next) => {
    Video.add(req, res)
        .then(([rows]) => {
            res.redirect('/video');
        })
        .catch(err => console.log(err));
};

//DELETE
exports.getDeleteVideo = (req, res, next) => {
    Video.deleteById(req.query.VID)
        .then(([rows]) => {
            res.redirect('/video');
        })
    .catch();
};

//UPDATE
exports.postUpdateVideo = (req, res, next) => {
    Video.updateById(req, res)
        .then(([rows]) => {
            res.redirect('/video');
        })
        .catch(err => console.log(err));
};