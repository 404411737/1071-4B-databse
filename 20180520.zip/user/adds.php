<?php session_start();?>
	<html>

		<head>
		</head>

		<body>
			<form class = "MAIN" name="form" method="post" action="adddrama.php">
				<p>Enter your drama name here :</p>	
				<input type="text" name="dramaname" />
				<input type = "submit" value = "post">
			</form>
		</body>
	
	</html>
	
	