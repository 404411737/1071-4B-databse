<?php session_start();?>
<?php
include("mysql_connect.inc.php");
mysql_query("set names utf8");

$gnum=$_POST['gnum'];
$nnnn=$_SESSION["dramaname"];

for($i=1;$i<=$gnum;$i++){
	 $sql="INSERT INTO $nnnn (groundname) values ('$i')";
	 if(mysql_query($sql))
            unset($_SESSION["nnnn"]);
    
}
            echo "<script>alert('好 就新增這麼多!');history.go(-1)</script>"; 


  /*echo "<script>alert('好 就新增這麼多!');history.go(-2)</script>"; 
            unset($_SESSION["dddd"]);
*/
?>