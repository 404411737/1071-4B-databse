<?php
    
    //從資料庫取得圖片
error_reporting(E_ALL ^ E_DEPRECATED);
    $conn=mysql_pconnect("localhost","root","1234");        
    mysql_select_db("mydb");
    mysql_query("SET NAMES'utf8'");
                    
    $sql=sprintf("select * from imagetest where id=11");
            
    $result=mysql_query($sql);        
    
    //顯示圖片
    if($row=mysql_fetch_assoc($result)){    
        header("Content-type: image/gif, image/jpeg, image/png ,image/jpg");     
        echo $row['image'];
    }
    
    mysql_close($conn);
    /*php
include("mysql_connect.inc.php");
$sql="SELECT * FROM classicBookShare WHERE count=12";
$result = $conn->query($sql);
$conn->close();

 //查詢結果
 if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
   $img=$row["bookImage"];
   $logodata = $img;
   echo '<img src="data:'.$row['imgType'].';base64,' . $logodata . '" />';
  }
 }
 else{

 }
 echo $img;*/

?>

