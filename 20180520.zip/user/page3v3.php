<?php session_start();?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
error_reporting(E_ALL ^ E_DEPRECATED);
                   $dnumber=$_GET['dramastore'];
                   //$_SESSION["dddd"]=$dnumber;
                   include("mysql_connect.inc.php");
                   $sql = "SELECT * FROM dramalist where dramanumber = '$dnumber'";
                   $result = mysql_query($sql);
                   while($row = mysql_fetch_array($result)){
                            $name1 = $row['dramaname'];
                            $_SESSION["dramaname"]=$name1;
    }

?>
<!DOCTYPE html>
<html>
    <head>
        <style>
            .1{
                position:absolute;
                height:20%;
                width: 100%;
                right:0;
                top:0;
            }
            .2{
                position:absolute;
                height:50%;
                width: 100%;
                right:0;
                top:20%;
            }
            .3{
                position:absolute;
                height:30%;
                width:100%;
                right:0;
                top:60%;
            }
            .btn{
    background-color: #32C7BF;
}

        </style>
    </head>
    <body>
        <div class="1">    
        </div>
        <div class="2">   
        <?php
                    error_reporting(E_ALL ^ E_DEPRECATED);
                    $db_server = "localhost";
                    $db_name = "mydb";
                    $db_user = "root";
                    $db_passwd = "";
                    $con = mysql_connect($db_server, $db_user, $db_passwd);
                    mysql_query("SET NAMES 'utf8'");
                    mysql_select_db($db_name);
                    $sql = " SELECT * FROM $name1";
                    $result = mysql_query($sql);
                    while($row = mysql_fetch_array($result)){
                        $str = $row['grounddrama'];
                        echo  $str  ;
                    }        
                ?> 
        </div>
        <div class="3">    
            <button onclick="self.location.href='addground.php'">按這裡新增場景</button> 
            <?php
                    error_reporting(E_ALL ^ E_DEPRECATED);
                    $db_server = "localhost";
                    $db_name = "mydb";
                    $db_user = "root";
                    $db_passwd = "";
                    $con = mysql_connect($db_server, $db_user, $db_passwd);
                    mysql_query("SET NAMES 'utf8'");
                    mysql_select_db($db_name);
                    
                    $sql2 = "SELECT * FROM $name1";
                    $result = mysql_query($sql2);
                    while($row = mysql_fetch_array($result)){
                        $str = $row['groundname'];
                        $gnumber = $row['groundnumber'];
                        echo "<a href=page3.php?groundstore=".$gnumber."> $str <br></a>";
                    }        
                ?>
        </div>
        </form>
    </body>
</html>