<?php session_start();?>
	<html>

		<head>
		</head>
   <script LANGUAGE="JavaScript">
    function checkNum(form){
    if (isNaN(document.main.Adult_Sit.value.valueOf()) )  {
       alert("只能輸入數字!!");
   return false;
    }
    else{
       return true;
    }

}

</script>
		<body>
			<form class = "ground" name="cut" method="post" action="addgroundnum.php">
				<p>你想要放入幾個場景 :</p>	
				<input type="gnumber" name="gnum" />
				<input type = "submit" value = "post" onClick="checkNum(this.form)">
			</form>
		</body>
	
	</html>
	