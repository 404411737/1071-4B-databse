<?php session_start();
if(isset($_SESSION['username'])){
 header("refresh:0.5;url=page2v3.php");  //轉址
 exit(); }//不執行之後的程式碼?>
<!DOCTYPE html>
    <html lang="en">
        <head>
            <title>實驗小劇場</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            <style>
                .navbar{
                    margin-bottom: 0;
                    border-radius: 0;
                    background-color: #FFFFFF;
                    padding: 0.5% 0;
                    font-size: 1.5em;
                    border: 0;
                }
                .navbar-brand{
                    float: left;
                    min-height: 65px;
                    padding: 0 15px 5px;
                }
                .navbar-default .navbar-bar .active a, .navbar-default .navbar-bar .active a:focus, .navbar-default .navbar-bar .active a:hover {
                     background-color: #F5F5F5;
                }
                footer{
                    width: 100%;
                    background-color: #FFFFFF;
                    padding: 1%;
                    bottom:0;
                    right:0;
                    position:absolute;
                }
                .row{
                    text-align:center;
                    display:flex;
                    align-items: center;
                    justify-content:center;
                }
                .main_container{
                    padding-top: 12px;
                    position:absolute;
                    height:90%;
                    width:100%;
                    top:4%;
                    right:0;
                    text-align:center;
                    display:flex;
                    align-items: center;
                    justify-content:center;
                    background-image: url("testbg2.jpg");
                }
                 #loginBar{
                    font-size:24px;
                    display:none;
                }
                #hint{
                    font-family: Microsoft JhengHei;
                    font-size:29px;
                    color: #666666;
                }
                #login{
                    color: #666666;
                }
                .btn-outline{
                    transition: all .5s;
                }
                .btn{
                    font-size:20px;
                    width:150px;
                    height:50px;
                    background-color: #F5F5F5;
                    color: #808080;
                    border-color: #808080;
                }
                .btn:hover{
                    background-color: #808080;
                    color: #F5F5F5;
                }
                #fox{
                    margin:10px 0px;
                }
                 #fox1{
                    margin:10px 100px;
                }
                #myNavbar{
                    padding-top: 5px;
                }
            </style>
            <script type = "text/javascript">
                var SP = jQuery.noConflict();
                SP(document).ready(function(){    
                    SP("#logo").mousedown(function(){
                        SP("#logoBar").hide();
                        SP("#loginBar").fadeIn(500);
                    });
                });
            </script><!--logo隱藏-->
            <script>
                var SP = jQuery.noConflict();
                SP(function(){
                    setInterval(flicker,1000);
                })
                function flicker(){
                    SP("#hint").fadeOut(500).fadeIn(500);
                }
            </script><!--閃爍腳本-->
        </head>
        <body>
            <nav class="navbar navbar-default" style="box-shadow:1px 1px 10px #8c8c8c;  z-index:2;">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span> 
                        </button>
                        <a class="navbar-brand" href="page1v3.html"><img src="compa.png"></a>
                    </div>
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav navbar-right">
                            <li ><a href="#">About us</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div class="main_container" style="z-index:1;">
                <div id="logoBar">
                    <p><img id="logo" src="compxx.png" style="margin-right:15px;"></p>
                </div>
                <div id="loginBar">
                    <div id="login">
                        <form name="form" method="post" action="connect.php" style="font-family:Microsoft JhengHei;">
                            <div class="form_group">
                                <label id="fox1" for="id">帳號</label><br/>
                                <input id="fox" type="text" class="form-control" name="id"/>
                                <label id="fox1" for="pw">密碼</label><br/>
                                <input id="fox" type="password" class="form-control" name="pw"/><br/>
                            <button id="fox1" type="submit" name="button" class="btn btn-outline btn-lg">登入</button>
                            </div>
                        </form>
                    </div>
                    <div id="register">
                        <br><button  id="fox1" name="sign" onclick="self.location.href='register.php'" class="btn btn-outline btn-lg">註冊</button>
                    </div>
                </div>
            </div>
            <footer class="container-fluid text-center" style="box-shadow:1px 1px 10px #8c8c8c; z-index:2;">
                <div class="row">
                    <div class="col-sm-1">
                        <a href="#"><img src="facebookx.png"></a>
                    </div>
                    <div class="col-sm-1">
                        <a href="#"><img src="googlex.png"></a>
                    </div>
                    <div class="col-sm-1">
                        <a href="#"><img src="twitterx.png"></a>
                    </div>
                    <div class="col-sm-1">
                        <a href="#"><img src="github.png"></a>
                    </div>
                </div>
            </footer>
        </body>
    </html>