<?php session_start();
//header("Content-type: image/gif, image/jpeg, image/png ,image/jpg"); ?>

<!DOCTYPE html>
    <html lang="en">
        <head>
            <title>實驗小劇場</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            <style>
                .navbar{
                    margin-bottom: 0;
                    border-radius: 0;
                    background-color: #F5F5F5;
                    padding: 1.0% 0;
                    font-size: 1.5em;
                    border: 0;
                }
                .navbar-brand{
                    float: left;
                    min-height: 65px;
                    padding: 0 15px 5px;
                    
                }
                .navbar-default .navbar-bar .active a, .navbar-default .navbar-bar .active a:focus, .navbar-default .navbar-bar .active a:hover {
                     background-color: #F5F5F5;
                }
               
                .row{
                    text-align:center;
                    display:flex;
                    align-items: center;
                    justify-content:center;
                }
                .main_container{
                    position:absolute;
                    height:100%;
                    width:100%;
                    right:0%;
                    background-color: #CCEEFF;
                }
                .btn-outline{
                    transition: all .5s;
                }
                .btn{
                    background-color: #32C7BF;
                    color: #F5F5F5;
                }
                .btn:focus,.btn.focus{
                    outline: 0;
                    background-color: #F5F5F5;
                    color: #32C7BF;
                }
                .btn:hover{
                    border-color: #32C7BF;
                    background-color: #F5F5F5;
                    color: #32C7BF;
                }
                .dramaBtn{
                    margin: 15px;
                    height: 100px;
                    min-width: 100px;
                    max-width: 100px;
                }
                .vertical-align-center {
                    display: table-cell;
                    vertical-align: middle;
                }
                #modalTile{
                    font-size: 18px;
                    font-family: "Helvetica Neue","Arial",sans-serif;
                }
                #dramaName{
                    resize: none;
                    width: 100%;
                }
                .imagecrop{                 
                     
                     height:30%;
                     width:40%;
                     background-color:#ffb6c1;
                      float:bottom;
                      text-align:center;
                      line-height:420%;
                     font-size:175%; 
                     margin:20px
                }
                .renamedrama{
                    
                     height:30%;
                     width:40%;
                     background-color:#ffb6c1;
                      float:bottom;
                      text-align:center;
                      line-height:420%;
                     font-size:175%;    
                      margin:20px                 
                }
                #nametext{
                    color:#000000;
                }
         
                .introduce{
                   
                     height:30%;
                     width:40%;
                     background-color:#ffb6c1;
                      float:bottom;
                      text-align:center;
                      line-height:420%;
                     font-size:175%; 
                       margin:20px
                }
                .cname{
                    height:5%;
                     width:100%;
                     background-color:#db7093;
                      float:bottom;
                      line-height:100%;
                      word-break:break-all;
                      font-size:100%;
                }
                
            </style>
        </head>
        <body>
            
            <div class="main_container" style="overflow-y:scroll;z-index=0">
				    <form name="form" method="post" action="updatedramaname_finish.php" style="font-family:Microsoft JhengHei;">
                            
                                <label for="newdramaname">請輸入欲更改的劇本名稱</label><br/>
                                <input type="text"  name="newdramaname"/><br/>                           
                            <button type="submit" name="button" class="btn btn-outline btn-lg">確定</button>
                            
                        </form>
             </div>
            
        </body>
    </html>