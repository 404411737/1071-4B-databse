<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
 <meta charset="utf-8">
<title>Choose your Script</title>
<style type="text/css">
	.ban{
 		background-color: #CD998B;
 		width:100%;
 		height: 120px;
		text-align: right;
	　　font-size:30px;
	    line-height: 100px;

 	}
 	.body{
 		background-color: #F8DFBD;
 		width: 100%;
 		height: 1080px;
 			
    
 	}
 	.slider{  
 		background-color: #F8DFBD;
 		width: 150px;
 		height: 100px;
 		float: left;
 	}
 	.bottom{
 		
 		background-color: #F3BB9A;
 		width: 100%;
 		height: 160px;
 	    float: left;
 	}
   .BFunction{
    	background-color: #CD998B;

        width:48px;
        height:48px;
        margin:30px;
        border: 4px ;
        box-shadow:2px 2px 4px 4px 	#BC8F8F;
    	float: left;
    }
    .BOX{
    background-color: #BF2A2A;
     width: 150px;
     height:200px;
     margin: 10px;
     float: left;
     text-align: center;
	 font-size:24px;
    
    }
    .BOXP{
    background-color: #F8DFBD;
    width: 150px;
    height: 200px;
    margin-left: 10px;
    margin-top: 10px;
    float: left; 
    }
 /*   .UserID{
    }
    .UserID .toolptext {
    visibility: hidden;
    width: 120px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;

    
}
    

 /*.UserID:hover {
    visibility: visible;
}*/
    
    #LOGOUT{   
        background-color: #F8DFBD;
        border: none;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
        transition-duration: 0.2s;
        color: #CD998B;
    }
    
</style>


<script src="/jquery/jquery-1.11.1.min.js"></script>
<script type="text/javascript"> </script>

    </head>
<body>
    <div class="ban">
        <!--<p id = "USERNAME">USERNAME : 
          <?php echo $_SESSION['username'];?> 
            <button id = "LOGOUT" onclick="self.location.href='logout.php'">LOGOUT</button></p> -->      
    </div>
    
    
<div class="body"><div class="BOX"><p>預設劇本</p>
<i class="material-icons">delete</i> 
<i class="material-icons">get_app</i> 
<i class="material-icons">create</i>  
</div><div id="BOXP"  ><img src="ADD.svg"  height="200" width="150"></div>
</div>


<div class="bottom"></div>
</body>
</html>

