<?php session_start();?>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);

    include("mysql_connect.inc.php");
    mysql_query("set names utf8");
    //mysqli_query($link, 'SET CHARACTER SET utf8');
    //mysqli_query("SET collation_connection = 'utf8_general_ci'");
    $upnumber= $_SESSION["upnumber"];
    $text=$_POST['editor'];
    //$gname1=$_SESSION["gname"];

    if($text!=null){
    $sql = "UPDATE dramalist SET introduce = '$text' WHERE dramanumber = '$upnumber'";
        if(mysql_query($sql))
        {
            //echo "ADDED INTO DB";
            //echo '<meta http-equiv=REFRESH CONTENT=2;url=page3.php>';
           echo "<script>alert('修改成功!');history.go(-3)</script>"; 
            unset($_SESSION["upnumber"]);
        }
        else
        {
            echo "ERROR WHILE INSERTING";
            //echo '<meta http-equiv=REFRESH CONTENT=2;url=page3.php >';
            echo "<script>alert('修改失敗 可憐!');history.go(-3)</script>";
            unset($_SESSION["upnumber"]);
            //$_SESSION['editor'];
        }
   }