<?php session_start();
//header("Content-type: image/gif, image/jpeg, image/png ,image/jpg"); ?>

<!DOCTYPE html>
    <html lang="en">
        <head>
            <title>實驗小劇場</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            <style>
                .main_container{
                    position:absolute;
                    height:100%;
                    width:100%;
                    right:0%;
                    background-color: #CCEEFF;
                }
                .imagecrop{                  
                     height:30%;
                     width:40%;
                     background-color:#ffb6c1;
                      float:bottom;
                      text-align:center;
                      line-height:1000%;
                     font-size:175%; 
                     margin:20px
                }
                .renamedrama{
                    
                     height:30%;
                     width:40%;
                     background-color:#ffb6c1;
                      float:bottom;
                      text-align:center;
                      line-height:1000%;
                     font-size:175%;    
                      margin:20px                 
                }
                #nametext{
                    color:#000000;
                }
         
                .introduce{
                   
                     height:30%;
                     width:40%;
                     background-color:#ffb6c1;
                      float:bottom;
                      text-align:center;
                      line-height:1000%;
                     font-size:175%; 
                       margin:20px
                }
                .deletedrama{
                	 height:30%;
                     width:40%;
                     background-color:#ffa500;
                      float:bottom;
                      text-align:center;
                      line-height:1000%;
                     font-size:175%; 
                       margin:20px
                }
            </style>
        </head>
        <body>
            <?php

$oldname=$_GET['dramaid'];
$upnumber=$_GET['dramastore'];
$_SESSION['upnumber']=$upnumber;
$_SESSION['oldname']=$oldname;
?>
            <div class="main_container" style="overflow-y:scroll;z-index=0">
				<div class="imagecrop"><a id="nametext" herf="#" onclick="self.location.href='imagejcrop.php'">更改預覽圖片<br/></a></div>
				<div class="renamedrama"><a id="nametext" herf="#" onclick="self.location.href='updatedramaname.php'">更改此劇本名稱<br/></a></div>
				<div class="introduce"><a id="nametext" herf="#" onclick="self.location.href='updateintroduce.php'">更改劇本簡介<br/></a></div>
				<div class="deletedrama"><a id="nametext" herf="#" onclick="self.location.href='deletedrama.php'">刪除此劇本<br/></a></div>
             </div>
            
        </body>
    </html>