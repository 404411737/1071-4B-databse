<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<form name="form" method="post" action="adddrama.php">
請輸入要加入的劇本名稱：<input type="text" name="dramaname" /> <br>

<input type="submit" name="button" value="確定" />
</form>