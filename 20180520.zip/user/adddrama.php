<?php session_start();?>
<!DOCTYPE html>
    <html lang="en">
        <head>
            <title>實驗小劇場</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            <style>
                .navbar{
                    margin-bottom: 0;
                    border-radius: 0;
                    background-color: #FFFFFF;
                    padding: 0.5% 0;
                    font-size: 1.5em;
                    border: 0;
                }
                .navbar-brand{
                    float: left;
                    min-height: 65px;
                    padding: 0 15px 5px;
                }
                .navbar-default .navbar-bar .active a, .navbar-default .navbar-bar .active a:focus, .navbar-default .navbar-bar .active a:hover {
                     background-color: #F5F5F5;
                }
                footer{
                    width: 100%;
                    background-color: #FFFFFF;
                    padding: 1%;
                    bottom:0;
                    right:0;
                    position:absolute;
                }
                .row{
                    text-align:center;
                    display:flex;
                    align-items: center;
                    justify-content:center;
                }
                .main_container{
                    padding-top: 12px;
                    position:absolute;
                    height:90%;
                    width:100%;
                    top:4%;
                    right:0;
                    text-align:center;
                    display:flex;
                    align-items: center;
                    justify-content:center;
                    background-image: url("testbg2.jpg");
                }
                 #loginBar{
                    font-size:24px;
                    display:none;
                }
                #hint{
                    font-family: Microsoft JhengHei;
                    font-size:29px;
                    color: #666666;
                }
                #login{
                    color: #666666;
                }
                .btn-outline{
                    transition: all .5s;
                }
                .btn{
                    font-size:20px;
                    width:150px;
                    height:50px;
                    background-color: #F5F5F5;
                    color: #808080;
                    border-color: #808080;
                }
                .btn:hover{
                    background-color: #808080;
                    color: #F5F5F5;
                }
                #fox{
                    margin:10px 0px;
                }
                 #fox1{
                    margin:10px 100px;
                }
                #myNavbar{
                    padding-top: 5px;
                }
            </style>
            
        </head>
        <body>
            <nav class="navbar navbar-default" style="box-shadow:3px 3px 12px   #666666; z-index: 1">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span> 
                        </button>
                        <ul class="nav navbar-nav navbar-left">
                             <a class="navbar-brand" href="#"><img src="compa.png"></a>
                        </ul>
                    </div>
                </div>
            </nav>
            <div class="main_container" >
                <?php
/*if(isset($_POST['dramaname'])){
$con = mysqli_connect('localhost','root','1234','mydb') or die("ERROR");//連接資料庫
mysqli_query($con,"SET CHARACTER SET UTF8");

$dramaname=$_POST['dramaname']
//$getDate= date("Y-m-d");

$query = mysqli_query($con,"INSERT INTO dramalist (dramaname,username,dramadate) VALUES ('$dramaname','$username','$dramadate')");//插進去
//$query = "INSERT INTO dramalist (dramaname ) VALUES ('$dramaname')";//插入表格語法
//mysqli_query($con, $query) or die("錯誤訊息：".mysqli_error($con));//執行插入
//echo "資料插入成功！";//顯示訊息
//mysqli_close($con);
if($query)
        {
            echo "ADDED INTO DB";
        }
        else
        {
            echo "ERROR WHILE INSERTING";
        }
    }
}*/

include("mysql_connect.inc.php");
mysql_query("set names utf8");

$dramaname=$_POST['dramaname'];
$username=$_SESSION['username'];

//$query = mysqli_query($con,"INSERT INTO dramalist (dramaname,username,dramadate) VALUES ('$dramaname','$username','$dramadate')");
//插進去
if($dramaname!=null){
$sql = "INSERT INTO dramalist (dramaname , username ) VALUES ('$dramaname' , '$username')";//插入表格語法
$sql2=sprintf("CREATE TABLE %s (groundnumber INT(255) UNSIGNED AUTO_INCREMENT PRIMARY KEY, groundname VArCHAR(2000)  , grounddrama TEXT(80000000)  NULL)DEFAULT CHARSET=utf8",$dramaname);
//mysqli_query($con, $query) or die("錯誤訊息：".mysqli_error($con));//執行插入
//echo "資料插入成功！";//顯示訊息null
//mysqli_close($con);
if(mysql_query($sql)&&mysql_query($sql2))
        {
            echo "<font size=9 face=\"竹風體W4\" color=\"magenta\">劇本成功加入 即將跳轉至劇本列頁面</font>";
            echo '<meta http-equiv=REFRESH CONTENT=2;url=page2v3.php>';
        }
        else
        {
            echo "ERROR WHILE INSERTING";
            echo '<meta http-equiv=REFRESH CONTENT=2;url=page2v3.php>';
        }
}  
/*if($dramaname!=null){
$sql = "INSERT INTO dramaticule (dramaname , username ,drama) VALUES ('$dramaname' , '$username' , ' ')";//插入表格語法
}   
if(mysql_query($sql))
        {
            echo "劇本成功加入! 即將跳轉至原畫面";
            echo '<meta http-equiv=REFRESH CONTENT=2;url=xx.php>';
        }
        else
        {
            echo "ERROR WHILE INSERTING";
            echo '<meta http-equiv=REFRESH CONTENT=2;url=xx.php>';
        }*/
        /*if($dramaname!=null){
        $sql=sprintf("CREATE TABLE %s (groundnumber INT(255) UNSIGNED AUTO_INCREMENT PRIMARY KEY, grounddrama TEXT(80000000)  NULL)DEFAULT CHARSET=utf8",$dramaname);
       /* $sql = "CREATE TABLE $dramaname(
       sentencenumber INT(255) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
       sentence TEXT(80000000) utf8mb4_general_ci NULL)";*/

/*if(mysql_query($sql))
        {
            echo "表成功建立!即將跳轉至原畫面";
            echo '<meta http-equiv=REFRESH CONTENT=2;url=page2v3.php>';
        }
        else
        {
            echo "ERROR WHILE INSERTING";
            echo '<meta http-equiv=REFRESH CONTENT=2;url=page2v3.php>';
        }
        }*/
?>
                
            </div>
            <footer class="container-fluid text-center" style="box-shadow: 5px 3px 24px   #666666;z-index:2">
            </footer>
        </body>
    </html>
<?php
/*if(isset($_POST['dramaname'])){
$con = mysqli_connect('localhost','root','1234','mydb') or die("ERROR");//連接資料庫
mysqli_query($con,"SET CHARACTER SET UTF8");

$dramaname=$_POST['dramaname']
//$getDate= date("Y-m-d");

$query = mysqli_query($con,"INSERT INTO dramalist (dramaname,username,dramadate) VALUES ('$dramaname','$username','$dramadate')");//插進去
//$query = "INSERT INTO dramalist (dramaname ) VALUES ('$dramaname')";//插入表格語法
//mysqli_query($con, $query) or die("錯誤訊息：".mysqli_error($con));//執行插入
//echo "資料插入成功！";//顯示訊息
//mysqli_close($con);
if($query)
        {
            echo "ADDED INTO DB";
        }
        else
        {
            echo "ERROR WHILE INSERTING";
        }
    }
}*/

/*include("mysql_connect.inc.php");
mysql_query("set names utf8");

$dramaname=$_POST['dramaname'];
$username=$_SESSION['username'];

//$query = mysqli_query($con,"INSERT INTO dramalist (dramaname,username,dramadate) VALUES ('$dramaname','$username','$dramadate')");
//插進去
if($dramaname!=null){
$sql = "INSERT INTO dramalist (dramaname , username ) VALUES ('$dramaname' , '$username')";//插入表格語法
$sql2=sprintf("CREATE TABLE %s (groundnumber INT(255) UNSIGNED AUTO_INCREMENT PRIMARY KEY, groundname VArCHAR(2000)  , grounddrama TEXT(80000000)  NULL)DEFAULT CHARSET=utf8",$dramaname);
//mysqli_query($con, $query) or die("錯誤訊息：".mysqli_error($con));//執行插入
//echo "資料插入成功！";//顯示訊息null
//mysqli_close($con);
if(mysql_query($sql)&&mysql_query($sql2))
        {
            echo "劇本成功加入 即將跳轉至原畫面";
            echo '<meta http-equiv=REFRESH CONTENT=2;url=page2v3.php>';
        }
        else
        {
            echo "ERROR WHILE INSERTING";
            echo '<meta http-equiv=REFRESH CONTENT=2;url=page2v3.php>';
        }
}  
/*if($dramaname!=null){
$sql = "INSERT INTO dramaticule (dramaname , username ,drama) VALUES ('$dramaname' , '$username' , ' ')";//插入表格語法
}   
if(mysql_query($sql))
        {
            echo "劇本成功加入! 即將跳轉至原畫面";
            echo '<meta http-equiv=REFRESH CONTENT=2;url=xx.php>';
        }
        else
        {
            echo "ERROR WHILE INSERTING";
            echo '<meta http-equiv=REFRESH CONTENT=2;url=xx.php>';
        }*/
        /*if($dramaname!=null){
        $sql=sprintf("CREATE TABLE %s (groundnumber INT(255) UNSIGNED AUTO_INCREMENT PRIMARY KEY, grounddrama TEXT(80000000)  NULL)DEFAULT CHARSET=utf8",$dramaname);
       /* $sql = "CREATE TABLE $dramaname(
       sentencenumber INT(255) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
       sentence TEXT(80000000) utf8mb4_general_ci NULL)";*/

/*if(mysql_query($sql))
        {
            echo "表成功建立!即將跳轉至原畫面";
            echo '<meta http-equiv=REFRESH CONTENT=2;url=page2v3.php>';
        }
        else
        {
            echo "ERROR WHILE INSERTING";
            echo '<meta http-equiv=REFRESH CONTENT=2;url=page2v3.php>';
        }
        }*/
?>