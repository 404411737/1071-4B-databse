<?php session_start();
if(isset($_SESSION['username'])){
 header("refresh:0.5;url=page2v3.php");  //轉址
 exit(); }?>
<!--上方語法為啟用session，此語法要放在網頁最前方-->
<!DOCTYPE html>
    <html lang="en">
        <head>
            <title>實驗小劇場</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            <style>
                .navbar{
                    margin-bottom: 0;
                    border-radius: 0;
                    background-color: #FFFFFF;
                    padding: 0.5% 0;
                    font-size: 1.5em;
                    border: 0;
                }
                .navbar-brand{
                    float: left;
                    min-height: 65px;
                    padding: 0 15px 5px;
                }
                .navbar-default .navbar-bar .active a, .navbar-default .navbar-bar .active a:focus, .navbar-default .navbar-bar .active a:hover {
                     background-color: #F5F5F5;
                }
                footer{
                    width: 100%;
                    background-color: #FFFFFF;
                    padding: 1%;
                    bottom:0;
                    right:0;
                    position:absolute;
                }
                .row{
                    text-align:center;
                    display:flex;
                    align-items: center;
                    justify-content:center;
                }
                .main_container{
                    padding-top: 12px;
                    position:absolute;
                    height:90%;
                    width:100%;
                    top:4%;
                    right:0;
                    text-align:center;
                    display:flex;
                    align-items: center;
                    justify-content:center;
                    background-image: url("testbg2.jpg");
                }
                 #loginBar{
                    font-size:24px;
                    display:none;
                }
                #hint{
                    font-family: Microsoft JhengHei;
                    font-size:29px;
                    color: #666666;
                }
                #login{
                    color: #666666;
                }
                .btn-outline{
                    transition: all .5s;
                }
                .btn{
                    font-size:20px;
                    width:150px;
                    height:50px;
                    background-color: #F5F5F5;
                    color: #808080;
                    border-color: #808080;
                }
                .btn:hover{
                    background-color: #808080;
                    color: #F5F5F5;
                }
                #fox{
                    margin:10px 0px;
                }
                 #fox1{
                    margin:10px 100px;
                }
                #myNavbar{
                    padding-top: 5px;
                }
            </style>
            
        </head>
        <body>
            <nav class="navbar navbar-default" style="box-shadow:3px 3px 12px   #666666;  z-index:2;">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span> 
                        </button>
                        <a class="navbar-brand" href="#"><img src="compa.png"></a>
                    </div>
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav navbar-right">
                            <li ><a href="#">About us</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div class="main_container" style="z-index:1;">
                <div class="connect" >
                	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
//連接資料庫
//只要此頁面上有用到連接MySQL就要include它
include("mysql_connect.inc.php");
$id = $_POST['id'];
$pw = $_POST['pw'];
//搜尋資料庫資料
$sql = "SELECT * FROM member_table where username = '$id'";
$result = mysql_query($sql);
$row = @mysql_fetch_row($result);
//判斷帳號與密碼是否為空白
//以及MySQL資料庫裡是否有這個會員
if($id != null && $pw != null && $row[0] == $id && $row[1] == $pw)
{
        //將帳號寫入session，方便驗證使用者身份
        $_SESSION['username'] = $id;
        $id1=$_SESSION['username'];
        //echo "登入成功! 歡迎回來 ";
        echo "<font size=9 face=\"竹風體W4\" color=\"mediumorchid\">登入成功! 歡迎回來 初級幼兒生</font>";
        echo "<font size=10 face=\"Jokerman\" color=\"PURPLE\">$id1</font>";
        echo '<meta http-equiv=REFRESH CONTENT=2;url=page2v3.php>';
}
else
{
        echo '登入失敗!';
        echo '<meta http-equiv=REFRESH CONTENT=1;url=page1v3.html>';
}
?>
               </div>
            </div>
              <footer class="container-fluid text-center" style="box-shadow: 5px 3px 24px   #666666;z-index:2;">
                <div class="row">
                  <div class="col-sm-1">
                        <a href="#"><img src="facebookx.png"></a>
                    </div>
                    <div class="col-sm-1">
                        <a href="#"><img src="googlex.png"></a>
                    </div>
                    <div class="col-sm-1">
                        <a href="#"><img src="twitterx.png"></a>
                    </div>
                    <div class="col-sm-1">
                        <a href="#"><img src="github.png"></a>
                    </div>
                </div>
            </footer>
        </body>
    </html>
<?php
//連接資料庫
//只要此頁面上有用到連接MySQL就要include它
/*include("mysql_connect.inc.php");
$id = $_POST['id'];
$pw = $_POST['pw'];
//搜尋資料庫資料
$sql = "SELECT * FROM member_table where username = '$id'";
$result = mysql_query($sql);
$row = @mysql_fetch_row($result);
//判斷帳號與密碼是否為空白
//以及MySQL資料庫裡是否有這個會員
if($id != null && $pw != null && $row[0] == $id && $row[1] == $pw)
{
        //將帳號寫入session，方便驗證使用者身份
        $_SESSION['username'] = $id;
        echo '登入成功! 歡迎回來  ';
        echo $_SESSION['username'];
        echo '<meta http-equiv=REFRESH CONTENT=2;url=page2v3.php>';
}
else
{
        echo '登入失敗!';
        echo '<meta http-equiv=REFRESH CONTENT=1;url=page1v3.html>';
}
?>*/