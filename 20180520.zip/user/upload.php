<?php session_start();?>

<?php
    
   /* //取得上傳檔案資訊
    $filename=$_FILES['image']['name'];
    $tmpname=$_FILES['image']['tmp_name'];
    $filetype=$_FILES['image']['type'];
    $filesize=$_FILES['image']['size'];    
    $file=NULL;
    
    if(isset($_FILES['image']['error'])){    
        if($_FILES['image']['error']==0){                                    
            $instr = fopen($tmpname,"rb" );
            $file = addslashes(fread($instr,filesize($tmpname)));        
        }
    }
    
    //新增圖片到資料庫
    $uploadnumber=$_SESSION["uploadnumber"];
    error_reporting(E_ALL ^ E_DEPRECATED);
    $conn=mysql_pconnect("localhost","root","1234");        
    mysql_select_db("mydb");
    mysql_query("SET NAMES'utf8'");

                   
    $sql=sprintf("update dramalist set image = %s where dramanumber = '$uploadnumber'","'".$file."'");
     if(mysql_query($sql)){
      echo "<script>alert('上傳成功!');history.go(-1)</script>"; 
}else{
    echo "<script>alert('上傳失敗 請重新嘗試!');history.go(-1)</script>"; 
}
            
    mysql_close($conn);*/
    //開啟圖片檔
   $file = fopen($_FILES["image"]["tmp_name"], "rb");
  // 讀入圖片檔資料
   $fileContents = fread($file, filesize($_FILES["image"]["tmp_name"])); 
  //關閉圖片檔
   fclose($file);
  //讀取出來的圖片資料必須使用base64_encode()函數加以編碼：圖片檔案資料編碼
    $fileContents = base64_encode($fileContents);
  
  //連結MySQL Server
    include("mysql_connect.inc.php");
    $uploadnumber=$_SESSION["uploadnumber"];
    error_reporting(E_ALL ^ E_DEPRECATED);
  //組合查詢字串
    $imgType=$_FILES["image"]["type"];
    $sql="UPDATE dramalist set image='$fileContents' , imgType='$imgType' WHERE dramanumber= '$uploadnumber'";

   if(mysql_query($sql)){
      echo "<script>alert('上傳成功!');history.go(-1)</script>"; 
}else{
    echo "<script>alert('上傳失敗 請重新嘗試!');history.go(-1)</script>"; 
}
    
?>

