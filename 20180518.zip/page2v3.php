<?php session_start();
//header("Content-type: image/gif, image/jpeg, image/png ,image/jpg"); ?>
<!DOCTYPE html>
    <html lang="en">
        <head>
            <title>實驗小劇場</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            <style>
                .navbar{
                    margin-bottom: 0;
                    border-radius: 0;
                    background-color: #FFFFFF;
                    padding: 0.5% 0;
                    font-size: 1.5em;
                    border: 0;
                }
                .navbar-brand{
                    float: left;
                    min-height: 65px;
                    padding: 0 15px 5px;
                    
                }
                .navbar-default .navbar-bar .active a, .navbar-default .navbar-bar .active a:focus, .navbar-default .navbar-bar .active a:hover {
                     background-color: #F5F5F5;
                }
                .row{
                    text-align:center;
                    display:flex;
                    align-items: center;
                    justify-content:center;
                }
                .main_container{
                    position:absolute;
                    height:91%;
                    width:100%;
                    top:9%;
                    right:0;
                    background-color: #f2f2f2;
                    padding-left: 1%;
                }
                .btn-outline{
                    transition: all .5s;
                }
                .btn{
                    padding-top: 5px;
                    font-size:20px;
                    width:150px;
                    height:50px;
                    background-color: #F5F5F5;
                    color: #808080;
                }
                .btn:hover{
                    background-color: #808080;
                    color: #F5F5F5;
                }
                .dramaBtn{
                    margin: 15px;
                    height: 100px;
                    min-width: 100px;
                    max-width: 100px;
                }
                .vertical-align-center {
                    display: table-cell;
                    vertical-align: middle;
                }
                #modalTile{
                    font-size: 18px;
                    font-family: "Helvetica Neue","Arial",sans-serif;
                }
                #dramaName{
                    resize: none;
                    width: 100%;
                }
                .idpaper{
                     height:78%;
                     width:22%;
                     min-width: 22.5%;
                     max-width: 45%;
                     float:left;
                     margin:1%;
                    box-shadow: 2px 2px 10px #8c8c8c;
                }
                .iddramaname{
                    height:12.5%;
                    width:100%;
                    background-image: url("12.jpg");
                    float:bottom;
                    text-align:center;
                    line-height:300%;
                    word-break:break-all;
                    font-size:200%;                      
                }
                #nametext{
                    text-decoration: none;
                    color:#666666;
                }
                .updateimage{
                    height:100%;
                    width:100%;
                    background-color:#ffffff;
                    float:right;
                    text-align:center;
                    line-height:500%;
                    font-size:100%;
                }
                .introduce{
                    height:37.5%;
                    width:100%;
                    background-color:#fafbfb;
                    float:bottom;
                    text-align:center;
                    line-height:130%;
                    word-break:break-all;
                    font-size:175%;
                    font-family: Microsoft JhengHei;
                }
                .cname{
                    height:5%;
                    width:100%;
                    background-image: url("eer.jpg");
                    float:bottom;
                    line-height:250%;
                    word-break:break-all;
                    font-size:100%;
                    text-align:center;
                    color: #666666;
                    font-family: Microsoft JhengHei;
                }
                .modal-dialog-centered{
                    
                }
                ::-webkit-scrollbar{
                    display: none;
                }
                #myNavbar{
                    padding-top: 5px;
                }
            </style>
        </head>
        <body style="overflow-y:hidden;">
            <nav class="navbar navbar-default" style="box-shadow:1px 1px 10px #8c8c8c; z-index: 2;">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span> 
                        </button>
                        <ul class="nav navbar-nav navbar-left">
                             <a class="navbar-brand" href="page1v3.php"><img src="compa.png"></a>
                        </ul>
                    </div>
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav navbar-right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-outline dropdown-toggle" data-toggle="dropdown">
                                    <span class="glyphicon glyphicon-th-list"></span>
                                    <font style="font-family:Microsoft JhengHei;"> 功能列</font>
                                </button>
                            <ul class="dropdown-menu" role="menu" style="min-width:150px; text-align: center; font-family:Microsoft JhengHei;">
                                <li class="divider"></li>
                                <li><a href="#" data-toggle="modal" data-target="#addDrama">新增劇本</a></li>
                                <li class="divider"></li>
                                <li><a href="#" onclick="self.location.href='logout.php'">帳號登出</a></li>
                                <li class="divider"></li>
                            </ul>
                            </div>
                        </ul>
                    </div>
                </div>
            </nav>
            <div class="main_container" style="overflow-y:scroll;z-index=1;">
            	<?php
    				error_reporting(E_ALL ^ E_DEPRECATED);
   					$db_server = "localhost";
    				$db_name = "mydb";
    				$db_user = "root";
    				$db_passwd = "1234";
    				$con = mysql_connect($db_server, $db_user, $db_passwd);
    				mysql_query("SET NAMES 'utf8'");
    				mysql_select_db($db_name);
    				$sql = " SELECT * FROM dramalist";
    				$result = mysql_query($sql);
    				while($row = mysql_fetch_array($result)){
        				$str = $row['dramaname'];
            			$dnumber = $row['dramanumber'];
                        $str1=$row['image'];  
                        $str2=$row['introduce'];
                        $str3=$row['username'];
                        //echo $row['image'];
                        if($str1==NULL){
                            /*echo '<div class="idpaper"><img src=see.jpg height="100%" width="50%" />
                            <div class="iddramaname">
                            <a id="nametext" href=page3v4.php?dramastore='.$dnumber.'> '.$str.' <br /></a>
                            <div class="updateimage">
                            <a id="nametext" href=imagejcrop.php?dramastore='.$dnumber.'> 編輯劇本圖像 <br /></a></div></div></div>';*/
                           
                           echo '<div class="idpaper"><a href=choosewhattodo.php?dramastore='.$dnumber.'&dramaid='.$str.'><img src=ees.png title="按這裡編輯劇本資訊" height="45%" width="100%" /></a>
                           <div class="iddramaname" ><a id="nametext" href=page3v4.php?dramastore='.$dnumber.' title="點擊進入劇本"> '.$str.' <br /></a></div>
                           <div class="introduce" style="overflow: scroll;"><font size="3" style="border-bottom-color:#666666;">簡介</font><br>'.$str2.'</div><div class="cname">建立者 : '.$str3.'</div></div>';

                        }else{
                            /*echo '<div class="idpaper"><img src= '.$str1.'  height="100%" width="50%" />
                            <div class="iddramaname">
                            <a id="nametext" href=page3v4.php?dramastore='.$dnumber.'> '.$str.' <br /></a>
                            <div class="updateimage">
                            <a id="nametext" href=imagejcrop.php?dramastore='.$dnumber.'> 編輯劇本圖像 <br /></a>
                            </div></div></div>';                       */
                           echo '<div class="idpaper"><a href=choosewhattodo.php?dramastore='.$dnumber.'&dramaid='.$str.'><img src= '.$str1.' title="按這裡編輯劇本資訊" height="45%" width="100%" /></a>
                            <div class="iddramaname" ><a id="nametext" href=page3v4.php?dramastore='.$dnumber.' title="點擊進入劇本"> '.$str.' <br /></a></div>
                            <div class="introduce" style="overflow: scroll;"><font size="3" style="border-bottom-color:#666666;">簡介</font><br>'.$str2.'</div><div class="cname">建立者:'.$str3.'</div></div>';


                        }                     
                		//echo "<button class='btn  dramaBtn'><a href=page3v4.php?dramastore=".$dnumber."> $str <br /></a></button>";
    				}        
				?>
                <div class="modal fade" id="addDrama" tabindex="-1" role="dialog" aria-labelledby="modalTile" aria-hidden="true" >
                    <div class="modal-dialog modal-dialog-centered " role="document">
                        <div class="modal-content" >
                            <form class = "MAIN" name="form" method="post" action="adddrama.php" >
                                <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <p class="modal-title" id="modalTile">請輸入劇本名稱 : </p>
                                <p class="modal-title" id="modalTile">※劇本名稱不可全為數字亦不可留白</p>
                                </div>
                                <div class="modal-body">
                                    <textarea name = "dramaname" id="dramaName"></textarea>
                                </div>
                                <div class="modal-footer">
                                    <input class="btn btn-light btn-outline" type = "submit" value = "ENTER" >
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="updatedrama" tabindex="-1" role="dialog" aria-labelledby="modalTile" aria-hidden="true" >
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content" >
                            <form class = "MAIN" name="form" method="post" action="updatedrama.php" >
                                <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <p class="modal-title" id="modalTile">請輸入想更改的劇本名稱</p>
                                </div>
                                <div class="modal-body">
                                    <textarea name = "newdramaname" id="newdramaname"></textarea>
                                </div>
                                <div class="modal-footer">
                                    <input class="btn btn-light" type = "submit" value = "確定" >
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </body>
    </html>