<?php session_start();?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
    error_reporting(E_ALL ^ E_DEPRECATED);
    $dnumber=$_GET['dramastore'];
    $_SESSION["uploadnumber"]=$dnumber;
    //$_SESSION["dddd"]=$dnumber;
    include("mysql_connect.inc.php");
    $sql = "SELECT * FROM dramalist where dramanumber = '$dnumber'";
    $result = mysql_query($sql);
    while($row = mysql_fetch_array($result)){
        $name1 = $row['dramaname'];
        $_SESSION["dramaname"]=$name1;
    }
?>
<!DOCTYPE html>
    <html lang="en">
        <head>
            <title>實驗小劇場</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            <script>
               $("#progressbarTWInput").change(function(){
                readURL(this);
                });
              function readURL(input){
              if(input.files && input.files[0]){
              var reader = new FileReader();
              reader.onload = function (e) {
              $("#preview_progressbarTW_img").attr('src', e.target.result);
              }
              reader.readAsDataURL(input.files[0]);
              }
           }
           </script>
            <style>
                .navbar{
                    margin-bottom: 0;
                    border-radius: 0;
                    background-color: #FFFFFF;
                    padding: 0.5% 0;
                    font-size: 1.5em;
                    border: 0;
                }
                .navbar-brand{
                    float: left;
                    min-height: 65px;
                    padding: 0 15px 5px;
                    
                }
                .navbar-default .navbar-bar .active a, .navbar-default .navbar-bar .active a:focus, .navbar-default .navbar-bar .active a:hover {
                     background-color: #F5F5F5;
                }
                footer{
                    width: 80%;
                    padding: 1%;
                    bottom: 0%;
                    left:20%;
                    position:fixed;
                }
                .main_container{
                    padding-top: 5px;
                    padding-left: 5px;
                    position:relative;
                    background-color: #F5F5F5;
                    height:80%;
                    width:80%;
                    right:0;
                }
                #modalTile{
                    font-size: 18px;
                    font-family: "Helvetica Neue","Arial",sans-serif;
                }
                #scenesNum{
                    resize: none;
                    width: 100%;
                }
                .vertical-align-center{
                    display: table-cell;
                    vertical-align: middle;
                }
                .main_timeliner{
                    background-color: #E0E0E0;
                    float: left;
                    height: 91%;
                    width: 20%;
                    top:9%;
                    padding-right: 0.8%;
                    overflow-y:scroll;
                }
                #timeline{
                    height: 20%;
                    width: 100%;
                }
                #barbox{
                    height: 100%;
                    width: 20%;
                    float: left;    
                }
                #info{
                    height: 80%;
                    width: 80%;
                    float: left;  
                }
                #info{
                    margin-top: 14px;
                    position: relative;
                    background: #FFFFFF;
                    border: 4px solid #FFFFFF;
                    box-shadow: 3px 3px 3px #BDBDBD;
                }
                #info:after, #info:before {
                    right: 100%;
                    top: 50%;
                    border: solid transparent;
                    content: " ";
                    height: 0;
                    width: 0;
                    position: absolute;
                    pointer-events: none;
                    
                }

                #info:after {
                    border-color: rgba(0, 0, 0, 0);
                    border-right-color: #FFFFFF;
                    border-width: 30px;
                    margin-top: -30px;
                    
                }
                #info:before {
                    border-color: rgba(0, 0, 0, 0);
                    border-right-color: #FFFFFF;
                    border-width: 36px;
                    margin-top: -36px;
                    
                }
                 #bar{
                    position: relative;
                    display: inline-block;
                    width: 10px;
                    height: 100%;
                    border: 10px solid rgba(96, 64, 32,2);
                    margin-left: 25%;
                }
                #toolbox{
                    font-family: sans-serif;
                    right:0;
                    height:100%;
                    width:20%;
                    float: left;
                    padding-left: 15px;
                    padding-top: 10px;
                }
                .toolbtn{
                    font-family: Microsoft JhengHei;
                    font-size: 20px;
                    height: 75px;
                    min-width: 355px;
                    background-color: #FFFFFF;
                    box-shadow: 3px 3px 5px #616161;
                }
                #infoIN{
                    padding: 2px 2px;
                    height:80%;
                    width:100%;
                    overflow-y:scroll;
                    color: #660000;
                    font-family: Microsoft JhengHei;
                    background-image: url("eer.jpg");
                }
                #infotime{
                    padding: 2px;
                    height:20%;
                    width:100%;
                }
                ::-webkit-scrollbar{
                    display: none;
                }
                .caret{
                    margin: 5px;
                }
                #scenes{
                    text-decoration: none;
                    color: #F5F5F5;
                }
                .lgbtn{
                    min-height: 60px;
                    border-radius: 40%;
                }
                 .btn-outline{
                    transition: all .5s;
                }
                .btn{
                    padding-top: 5px;
                    font-size:20px;
                    width:150px;
                    height:50px;
                    background-color: #F5F5F5;
                    color: #808080;
                }
                .btn:hover{
                    background-color: #808080;
                    color: #F5F5F5;
                }
                #myNavbar{
                    padding-top: 5px;
                }
                .sceneBtn{
                    width:100px;
                    height:70px;
                    margin-right: 20px;
                    background-image: url("9.jpg");
                }
                .sceneBtn:hover{
                    background-image: url("9.jpg");
                }
            </style>
        </head>
        <body>
            <nav class="navbar navbar-default" style="box-shadow:1px 1px 10px #8c8c8c; z-index: 2;">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span> 
                        </button>
                        <a class="navbar-brand" href="page1v3.php"><img src="compa.png"></a>
                    </div>
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav navbar-right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-outline dropdown-toggle" data-toggle="dropdown">
                                    <span class="glyphicon glyphicon-th-list"></span>
                                    <font style="font-family:Microsoft JhengHei;"> 功能列</font>
                                </button>
                            <ul class="dropdown-menu" role="menu" style="min-width:150px; text-align: center; font-family:Microsoft JhengHei;">
                                <li class="divider"></li>
                                <li><a href="#" onclick="self.location.href='imagejcrop.php'">上傳劇本圖片</a></li>
                                <li class="divider"></li>
                                <li><a href="#" data-toggle="modal" data-target="#addSecnes">新增場景</a></li>
                                <li class="divider"></li>
                                <li><a href="#" onclick="self.location.href='logout.php'">帳號登出</a></li>
                                <li class="divider"></li>
                            </ul>
                            </div>
                        </ul>
                    </div>
                </div>
            </nav>
           <div class="main_timeliner text-left" style="z-index:3;">
                <?php
                    error_reporting(E_ALL ^ E_DEPRECATED);
                    $db_server = "localhost";
                    $db_name = "mydb";
                    $db_user = "root";
                    $db_passwd = "1234";
                    $con = mysql_connect($db_server, $db_user, $db_passwd);
                    mysql_query("SET NAMES 'utf8'");
                    mysql_select_db($db_name);
                    $sql = " SELECT * FROM $name1";
                    $result = mysql_query($sql);
                    $SC = array();
                    while($row = mysql_fetch_array($result)){
                        $str = $row['grounddrama'];
                        $vender_c = explode("@", $str);
                        if($str ==''){
                        }else{
                            foreach($vender_c as $value => $item){
                                $item_sp = explode("#",$item);
                                if(count($item_sp)==1){
                                    $content = $item_sp[0];
                                    echo "<div id='timeline'><div id='barbox'><i id='bar'></i></div><div id='info'><div id='infotime'></div><div id='infoIN' > $content </div></div></div>";
                                }else{
                                    $time_sp = explode("</p>",$item_sp[0]);
                                    $time_spc = count($time_sp);
                                    if($time_spc==1){
                                        $time = $time_sp[0];
                                        $content = $item_sp[1];    
                                        array_unshift($SC,substr($time,-4,2));
                                        echo "<div id='timeline'><div id='barbox'><i id='bar'></i></div><div id='info'><div id='infotime'> $time </div><div id='infoIN' > $content </div></div></div>";
                                    }else{
                                        $time2 = $time_sp[1];
                                        $content = $item_sp[1];
                                        array_unshift($SC,substr($time2,-4,2));
                                        if((int)$SC[0]-(int)$SC[1]>=2 && (int)$SC[0]-(int)$SC[1]<=5){
                                            echo "<div id='timeline'><div id='barbox'><i id='bar'></i></div></div>";
                                            echo "<div id='timeline'><div id='barbox'><i id='bar'></i></div><div id='info'><div id='infotime'> $time2 </div><div id='infoIN' > $content </div></div></div>";
                                        }elseif(((int)$SC[0]-(int)$SC[1])>=6 && (int)$SC[0]-(int)$SC[1]<=9){
                                            echo "<div id='timeline'><div id='barbox'><i id='bar'></i></div></div>";
                                            echo "<div id='timeline'><div id='barbox'><i id='bar'></i></div></div>";
                                            echo "<div id='timeline'><div id='barbox'><i id='bar'></i></div><div id='info'><div id='infotime'> $time2 </div><div id='infoIN' > $content </div></div></div>";
                                        }elseif(((int)$SC[0]-(int)$SC[1])>=10){
                                            echo "<div id='timeline'><div id='barbox'><i id='bar'></i></div></div>";
                                            echo "<div id='timeline'><div id='barbox'><i id='bar'></i></div></div>";
                                            echo "<div id='timeline'><div id='barbox'><i id='bar'></i></div></div>";
                                            echo "<div id='timeline'><div id='barbox'><i id='bar'></i></div></div>";
                                            echo "<div id='timeline'><div id='barbox'><i id='bar'></i></div><div id='info'><div id='infotime'> $time2 </div><div id='infoIN' > $content </div></div></div>";
                                        }else{
                                            echo "<div id='timeline'><div id='barbox'><i id='bar'></i></div><div id='info'><div id='infotime'> $time2 </div><div id='infoIN' > $content </div></div></div>";
                                        }
                                    }
                                }
                            }
                        }
                    }
                ?>
            </div>
            <div class="modal fade" id="addSecnes" tabindex="-1" role="dialog" aria-labelledby="modalTile" aria-hidden="true" >
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content" >
                        <form class="ground" name="cut" method="post" action="addgroundnum.php">
                            <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <p class="modal-title" id="modalTile">How many scenes do you want to add ?</p>
                            </div>
                            <div class="modal-body">
                                <textarea type="gnumber" name="gnum" id="scenesNum"></textarea>
                            </div>
                            <div class="modal-footer">
                                <input class="btn btn-light" type="submit" value="ENTER">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="main_container" style="overflow-y:scroll; z-index:1;">
                <?php
                    error_reporting(E_ALL ^ E_DEPRECATED);
                    $db_server = "localhost";
                    $db_name = "mydb";
                    $db_user = "root";
                    $db_passwd = "1234";
                    $con = mysql_connect($db_server, $db_user, $db_passwd);
                    mysql_query("SET NAMES 'utf8'");
                    mysql_select_db($db_name);
                    $sql = " SELECT * FROM $name1";
                    $result = mysql_query($sql);
                    while($row = mysql_fetch_array($result)){
                        $str = $row['grounddrama'];
                        echo  $str;
                    }        
                ?>
            </div>
            <footer style="z-index: 2;">
                <div id="scenesbox">
                    <?php
                        error_reporting(E_ALL ^ E_DEPRECATED);
                        $db_server = "localhost";
                        $db_name = "mydb";
                        $db_user = "root";
                        $db_passwd = "1234";
                        $con = mysql_connect($db_server, $db_user, $db_passwd);
                        mysql_query("SET NAMES 'utf8'");
                        mysql_select_db($db_name);
                        $sql2 = "SELECT * FROM $name1";
                        $result = mysql_query($sql2);
                        while($row = mysql_fetch_array($result)){
                            $str = $row['groundname'];
                            $gnumber = $row['groundnumber'];
                            echo "<button class='btn btn-outline sceneBtn' style='box-shadow:1px 1px 10px #8c8c8c;'><a id='scenes' href=page3.php?groundstore=".$gnumber."> $str <br></a></button>";
                        }        
                    ?>  
                </div>
            </footer>
        </body>
    </html>