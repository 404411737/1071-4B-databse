
<?php
/*if(isset($_POST['dramaname'])){
$con = mysqli_connect('localhost','root','1234','mydb') or die("ERROR");//連接資料庫
mysqli_query($con,"SET CHARACTER SET UTF8");

$dramaname=$_POST['dramaname']
//$getDate= date("Y-m-d");

$query = mysqli_query($con,"INSERT INTO dramalist (dramaname,username,dramadate) VALUES ('$dramaname','$username','$dramadate')");//插進去
//$query = "INSERT INTO dramalist (dramaname ) VALUES ('$dramaname')";//插入表格語法
//mysqli_query($con, $query) or die("錯誤訊息：".mysqli_error($con));//執行插入
//echo "資料插入成功！";//顯示訊息
//mysqli_close($con);
if($query)
        {
            echo "ADDED INTO DB";
        }
        else
        {
            echo "ERROR WHILE INSERTING";
        }
    }
}*/
include("mysql_connect.inc.php");
$dramaname=$_POST['dramaname'];
$username='qwer';

//$query = mysqli_query($con,"INSERT INTO dramalist (dramaname,username,dramadate) VALUES ('$dramaname','$username','$dramadate')");
//插進去
if($dramaname!=null){
$sql = "INSERT INTO dramalist (dramaname , username ) VALUES ('$dramaname' , '$username')";//插入表格語法
//mysqli_query($con, $query) or die("錯誤訊息：".mysqli_error($con));//執行插入
//echo "資料插入成功！";//顯示訊息
//mysqli_close($con);
if(mysql_query($sql))
        {
            echo "劇本成功加入! 即將跳轉至原畫面";
            echo '<meta http-equiv=REFRESH CONTENT=2;url=xx.php>';
        }
        else
        {
            echo "ERROR WHILE INSERTING";
            echo '<meta http-equiv=REFRESH CONTENT=2;url=xx.php>';
        }
}    
?>