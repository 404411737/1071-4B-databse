<?php session_start();
if(isset($_SESSION['username'])){
 header("refresh:0.5;url=page2v3.php");  //轉址
 exit(); }//不執行之後的程式碼?>
<!DOCTYPE html>
    <html lang="en">
        <head>
            <title>實驗小劇場</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            <style>
                .navbar{
                    margin-bottom: 0;
                    border-radius: 0;
                    background-color: #F5F5F5;
                    padding: 1.0% 0;
                    font-size: 1.5em;
                    border: 0;
                }
                .navbar-brand{
                    float: left;
                    min-height: 65px;
                    padding: 0 15px 5px;
                }
                .navbar-default .navbar-bar .active a, .navbar-default .navbar-bar .active a:focus, .navbar-default .navbar-bar .active a:hover {
                     background-color: #F5F5F5;
                }
                footer{
                    width: 100%;
                    background-color: #F5F5F5;
                    padding: 2%;
                    bottom:0;
                    right:0;
                    position:absolute;
                }

                .row{
                    text-align:center;
                    display:flex;
                    align-items: center;
                    justify-content:center;
                }
                .main_container{
                    padding-top: 12px;
                    position:absolute;
                    height:80%;
                    width:100%;
                    top:10%;
                    right:0;
                    text-align:center;
                    display:flex;
                    align-items: center;
                    justify-content:center;
                    background-color: #CCEEFF;

                }
                 #loginBar{
                    font-size:24px;
                    display:none;
                }
                #hint{
                    font-family:Microsoft JhengHei;
                    font-size:29px;
                    color: #32C7BF;
                }
                #login{
                    color: #32C7BF;
                }
                .btn-outline{
                    transition: all .5s;
                }
                .btn{
                    font-size:16px;
                    width:100px;
                    height:40px;
                    background-color: #32C7BF;
                    color: #F5F5F5;
                }
                .btn:hover{
                    border-color: #32C7BF;
                    background-color: #F5F5F5;
                    color: #32C7BF;
                }
            </style>
            <script type = "text/javascript">
                var SP = jQuery.noConflict();
                SP(document).ready(function(){    
                    SP("#logo").mousedown(function(){
                        SP("#logoBar").hide();
                        SP("#loginBar").fadeIn(500);
                    });
                });
            </script><!--logo隱藏-->
            <script>
                var SP = jQuery.noConflict();
                SP(function(){
                    setInterval(flicker,1000);
                })
                function flicker(){
                    SP("#hint").fadeOut(500).fadeIn(500);
                }
            </script><!--閃爍腳本-->
        </head>
        <body>
            <nav class="navbar navbar-default" style="box-shadow:3px 3px 12px   #666666;  z-index:2;">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span> 
                        </button>
                        <a class="navbar-brand" href="page1v3.php"><img src="logoX.png"></a>
                    </div>
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav navbar-right">
                            <li ><a href="#">About us</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div class="main_container" style="z-index:1;">
                <div id="logoBar">
                    <p><img id="logo" src="logoN.png"></p>
                    <br>
                    <p id="hint">Click logo to continue</p>
                </div>
                <div id="loginBar">
                    <div id="login">
                        <form name="form" method="post" action="connect.php" style="font-family:Microsoft JhengHei;">
                            <div class="form group">
                                <label for="id">Account</label><br/>
                                <input type="text" class="form-control" name="id"/><br/>
                                <label for="pw">Password</label><br/>
                                <input type="password" class="form-control" name="pw"/><br/>
                            <button type="submit" name="button" class="btn btn-outline btn-lg">LOGIN</button>
                            </div>
                        </form>
                    </div>
                    <div id="register">
                        <br><button name="sign" onclick="self.location.href='register.php'" class="btn btn-outline btn-lg">SIGN</button>
                    </div>
                </div>
            </div>
            <footer class="container-fluid text-center" style="box-shadow: 5px 3px 24px   #666666;z-index:2;">
                <div class="row">
                    <div class="col-sm-1">
                        <a href="#"><img src="instagram.png"></a>
                    </div>
                    <div class="col-sm-1">
                        <a href="#"><img src="facebook.png"></a>
                    </div>
                    <div class="col-sm-1">
                        <a href="#"><img src="twitter.png"></a>
                    </div>
                    <div class="col-sm-1">
                        <a href="#"><img src="google-plus.png"></a>
                    </div>
                </div>
            </footer>
        </body>
    </html>