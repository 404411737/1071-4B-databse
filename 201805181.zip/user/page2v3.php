<?php session_start();
//header("Content-type: image/gif, image/jpeg, image/png ,image/jpg"); ?>
<!DOCTYPE html>
    <html lang="en">
        <head>
            <title>實驗小劇場</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            <style>
                .navbar{
                    margin-bottom: 0;
                    border-radius: 0;
                    background-color: #F5F5F5;
                    padding: 1.0% 0;
                    font-size: 1.5em;
                    border: 0;
                }
                .navbar-brand{
                    float: left;
                    min-height: 65px;
                    padding: 0 15px 5px;
                    
                }
                .navbar-default .navbar-bar .active a, .navbar-default .navbar-bar .active a:focus, .navbar-default .navbar-bar .active a:hover {
                     background-color: #F5F5F5;
                }
               
                .row{
                    text-align:center;
                    display:flex;
                    align-items: center;
                    justify-content:center;
                }
                .main_container{
                    position:absolute;
                    height:100%;
                    width:100%;
                    top:12.5%;
                    right:0%;
                    background-color: #CCEEFF;
                }
                .btn-outline{
                    transition: all .5s;
                }
                .btn{
                    background-color: #32C7BF;
                    color: #F5F5F5;
                }
                .btn:focus,.btn.focus{
                    outline: 0;
                    background-color: #F5F5F5;
                    color: #32C7BF;
                }
                .btn:hover{
                    border-color: #32C7BF;
                    background-color: #F5F5F5;
                    color: #32C7BF;
                }
                .dramaBtn{
                    margin: 15px;
                    height: 100px;
                    min-width: 100px;
                    max-width: 100px;
                }
                .vertical-align-center {
                    display: table-cell;
                    vertical-align: middle;
                }
                #modalTile{
                    font-size: 18px;
                    font-family: "Helvetica Neue","Arial",sans-serif;
                }
                #dramaName{
                    resize: none;
                    width: 100%;
                }
                .idpaper{
                     height:78%;
                     width:22.5%;
                     min-width: 22.5%;
                     max-width: 45%;
                     
                     float:left;
                     margin:20px
                }
                .iddramaname{
                     height:12.5%;
                     width:100%;
                     background-color:#ffb6c1;
                      float:bottom;
                      text-align:center;
                      line-height:420%;
                      word-break:break-all;
                      font-size:175%;                      
                }
                #nametext{
                    color:#000000;
                }
                .updateimage{
                     height:100%;
                     width:100%;
                     background-color:  #e6e6fa;
                      float:right;
                      text-align:center;
                      line-height:500%;
                      font-size:100%;
                }
                .introduce{
                    height:40%;
                     width:100%;
                     background-color:#e6e6fa;
                      float:bottom;
                      line-height:100%;
                      word-break:break-all;
                      font-size:175%;
                }
                .cname{
                    height:5%;
                     width:100%;
                     background-color:#db7093;
                      float:bottom;
                      line-height:300%;
                      word-break:break-all;
                      font-size:100%;
                      text-align:center;
                }
                
            </style>
        </head>
        <body>
            <nav class="navbar navbar-default" style="box-shadow:3px 3px 12px   #666666; z-index: 1">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span> 
                        </button>
                        <ul class="nav navbar-nav navbar-left">
                             <a class="navbar-brand" href="page1v3.php"><img src="logoX.png"></a>
                        </ul>
                    </div>
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav navbar-right">
                            <button type="button" class="btn btn-outline navbar-btn btn-lg" data-toggle="modal" data-target="#addDrama">
                                ADD NEW DRAMA
                            </button>
                            <button class="btn btn-outline navbar-btn btn-lg" onclick="self.location.href='logout.php'">LOGOUT</button>
                        </ul>
                    </div>
                </div>
            </nav>
            <div class="main_container" style="overflow-y:scroll;z-index=0">
            	<?php
    				error_reporting(E_ALL ^ E_DEPRECATED);
   					$db_server = "localhost";
    				$db_name = "mydb";
    				$db_user = "root";
    				$db_passwd = "1234";
    				$con = mysql_connect($db_server, $db_user, $db_passwd);
    				mysql_query("SET NAMES 'utf8'");
    				mysql_select_db($db_name);
    				$sql = " SELECT * FROM dramalist";
    				$result = mysql_query($sql);
    				while($row = mysql_fetch_array($result)){
        				$str = $row['dramaname'];
            			$dnumber = $row['dramanumber'];
                        $str1=$row['image'];  
                        $str2=$row['introduce'];
                        $str3=$row['username'];
                        //echo $row['image'];
                        if($str1==NULL){
                            /*echo '<div class="idpaper"><img src=see.jpg height="100%" width="50%" />
                            <div class="iddramaname">
                            <a id="nametext" href=page3v4.php?dramastore='.$dnumber.'> '.$str.' <br /></a>
                            <div class="updateimage">
                            <a id="nametext" href=imagejcrop.php?dramastore='.$dnumber.'> 編輯劇本圖像 <br /></a></div></div></div>';*/
                           
                           echo '<div class="idpaper"><a href=choosewhattodo.php?dramastore='.$dnumber.'&dramaid='.$str.'><img src=see.jpg title="按這裡編輯劇本資訊" height="45%" width="100%" /></a>
                           <div class="iddramaname" ><a id="nametext" href=page3v4.php?dramastore='.$dnumber.' title="點擊進入劇本"> '.$str.' <br /></a></div>
                           <div class="introduce" style="overflow: scroll;"><font size="3">簡介:</font><br>'.$str2.'</div><div class="cname">建立者:'.$str3.'</div></div>';

                        }else{
                            /*echo '<div class="idpaper"><img src= '.$str1.'  height="100%" width="50%" />
                            <div class="iddramaname">
                            <a id="nametext" href=page3v4.php?dramastore='.$dnumber.'> '.$str.' <br /></a>
                            <div class="updateimage">
                            <a id="nametext" href=imagejcrop.php?dramastore='.$dnumber.'> 編輯劇本圖像 <br /></a>
                            </div></div></div>';                       */
                           echo '<div class="idpaper"><a href=choosewhattodo.php?dramastore='.$dnumber.'&dramaid='.$str.'><img src= '.$str1.' title="按這裡編輯劇本資訊" height="45%" width="100%" /></a>
                            <div class="iddramaname" ><a id="nametext" href=page3v4.php?dramastore='.$dnumber.' title="點擊進入劇本"> '.$str.' <br /></a></div>
                            <div class="introduce" style="overflow: scroll;"><font size="3">簡介:</font><br>'.$str2.'</div><div class="cname">建立者:'.$str3.'</div></div>';


                        }                     
                		//echo "<button class='btn  dramaBtn'><a href=page3v4.php?dramastore=".$dnumber."> $str <br /></a></button>";
    				}        
				?>
                <div class="modal fade" id="addDrama" tabindex="-1" role="dialog" aria-labelledby="modalTile" aria-hidden="true" >
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content" >
                            <form class = "MAIN" name="form" method="post" action="adddrama.php" >
                                <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <p class="modal-title" id="modalTile">Enter your drama name here (不可全為數字 中間不可留空):</p>
                                </div>
                                <div class="modal-body">
                                    <textarea name = "dramaname" id="dramaName"></textarea>
                                </div>
                                <div class="modal-footer">
                                    <input class="btn btn-light" type = "submit" value = "ENTER" >
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="updatedrama" tabindex="-1" role="dialog" aria-labelledby="modalTile" aria-hidden="true" >
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content" >
                            <form class = "MAIN" name="form" method="post" action="updatedrama.php" >
                                <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <p class="modal-title" id="modalTile">請輸入想更改的劇本名稱</p>
                                </div>
                                <div class="modal-body">
                                    <textarea name = "newdramaname" id="newdramaname"></textarea>
                                </div>
                                <div class="modal-footer">
                                    <input class="btn btn-light" type = "submit" value = "確定" >
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
        </body>
    </html>