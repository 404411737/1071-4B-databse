<?php
error_reporting(E_ALL ^ E_DEPRECATED);

$db_server = "localhost";
//資料庫名稱
$db_name = "mydb";
//資料庫管理者帳號
$db_user = "root";
//資料庫管理者密碼
$db_passwd = "1234";
//對資料庫連線
    $con = mysql_connect($db_server, $db_user, $db_passwd) ;//連接資料庫
    mysql_query("SET NAMES 'utf8'");//設定語系
    mysql_select_db($db_name);
    $sql = " SELECT * FROM dramalist";//查詢整個表單
    $result = mysql_query($sql) ;
    while($row = mysql_fetch_array($result)){//印出資料
  echo $row['dramaname']."<br>";
    }
?>