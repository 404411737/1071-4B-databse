<?php session_start();?>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);

    include("mysql_connect.inc.php");
    mysql_query("set names utf8");
    //mysqli_query($link, 'SET CHARACTER SET utf8');
    //mysqli_query("SET collation_connection = 'utf8_general_ci'");
    $dddd= $_SESSION["dddd"];
    $text=$_POST['editor'];
    $nnnn=$_SESSION["nnnn"];

    if($text!=null){
    $sql = "UPDATE dramalist SET drama = '$text' WHERE dramanumber = '$dddd'";
        if(mysql_query($sql))
        {
            //echo "ADDED INTO DB";
            //echo '<meta http-equiv=REFRESH CONTENT=2;url=page3.php>';
           echo "<script>alert('修改成功!');history.go(-2)</script>"; 
            unset($_SESSION["dddd"]);
        }
        else
        {
            echo "ERROR WHILE INSERTING";
            //echo '<meta http-equiv=REFRESH CONTENT=2;url=page3.php >';
            echo "<script>alert('修改失敗 可憐!');history.go(-1)</script>";
            unset($_SESSION["dddd"]);
            //$_SESSION['editor'];
        }
   }
  /* if($text!=null){
    $string = $text;

    $cutchar = explode(" ", $string);

    $nums=count($cutchar);
    for($x=0; $x < $nums; $x++){
        //echo "\$cutchar[".$x."]：".$cutchar[$x]."<br />";
        $use=$cutchar[$x];
        $sql = "INSERT INTO $nnnn (sentence) VALUES ('$use')";
    }
   
    //$sql = "UPDATE dramaticule SET drama = '$text' WHERE dnumber = '$dddd'";
        if(mysql_query($sql))
        {
            echo "ADDED INTO DB";
            //echo '<meta http-equiv=REFRESH CONTENT=2;url=page3.php>';
           //echo "<script>alert('修改成功!');history.go(-1)</script>"; 
            //unset($_SESSION["dddd"]);
        }
        else
        {
            echo "ERROR WHILE INSERTING";
            //echo '<meta http-equiv=REFRESH CONTENT=2;url=page3.php >';
            //echo "<script>alert('修改失敗 可憐!');history.go(-1)</script>";
            //unset($_SESSION["dddd"]);
            //$_SESSION['editor'];
        }
   }

    /*if(isset($_POST['editor']))
    {
        $text = $_POST['editor'];
        //連到database
        //$con = mysqli_connect('localhost','root','1234','mydb') or die("ERROR");
        //插進session
        //$_SESSION['editor'] = $text;
        //插入data 不過後來用SESSION了
        //$query = mysqli_query($con,"INSERT INTO content (content) VALUES ('$text')");
       // $sql = mysqli_query($con,"UPDATE dramaticule SET drama = '$text' WHERE dramaname = '$dramaname1'");
        $sql = "UPDATE dramaticule SET drama = '$text' WHERE dramaname = '$dramaname1'";
        if($query)
        {
            echo "ADDED INTO DB";
        }
        else
        {
            echo "ERROR WHILE INSERTING";
            //$_SESSION['editor'];
        }
    }*/


?>