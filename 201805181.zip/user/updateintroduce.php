<?php session_start();
if(!isset($_SESSION['username'])){
 echo "抱歉 您尚未登入 如要繼續使用請先登入!";
 header("refresh:2;url=page1v3.html");  //轉址
 exit(); }//不執行之後的程式碼?>
    <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link href="semantic/semantic.min.css" rel="stylesheet" type="text/css">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            <script src="ckeditor/ckeditor.js"></script>
            <script src="semantic/jquery-3.2.1.min.js"></script>
            <script src="semantic/semantic.min.js"></script>
            <meta charset="utf-8">    
            <title>實驗小劇場</title>
            <style>
                .HEADER{
                    position:absolute;
                    height:10%;
                    width:100%;
                    background-color:#FFCC22;
                    display:flex;
                    align-items:center;
                    justify-content:flex-end;
                    float:inherit;
                    top:0;
                    right:0;
                    
                }
                .CONTAINER{
                    position:absolute;
                    height:85%;
                    width:100%;
                    background-color:#FFFFFF;
                    text-align:center;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    top:10%;
                    right:0;
                }
                #testbar{
                    font-family:Microsoft JhengHei;
                    color:#FFFFFF;
                    display:none;
                }
                .updatename{
                max-width:250px;
                max-height:100px;
                width:250px;
                height:100px;
                }
                textarea {
                 resize : none;
                 }
                 .updategroundname{
                 
                 }     
                 .ck{
                    width:100%;
                    height:100%;
                 } 
                 a{
color:black;
text-decoration:none;
}
ul{
    width: 180px;
    height: 50px;
    display: inline;
    margin: 5px;
    padding: 0;
}
ul {
    display: inline-block;
}
ul a:hover{
    background-color: #FFBB00;
    color: white;
}
.top2function{
color: black;
padding-right:15px;
padding-top:15px;
padding-bottom: 15px;
font-size: 30px;
display: inline-block;
background-color: #FFCC22;
height: 50px;
width: 100%;
text-align:right;
}
.btn{
                    font-size: 30px;
                    background-color: #FFCC22;
                    color: black;
                    border:2px #FFCC22 dashed;
                }
                #groundname{
                    resize: none;
                    width: 100%;
                }
                .seeground{
                    height:100%;
                    width:500px;
                    color:purple;
                    font-size: 40px;
                }
                 .ck{
                    width:100%;
                    height:100%;
                 } 
  </style>
            
        </head>       
        <body>
            <div class ="HEADER">
                <div class="top2function"><ul><a href="logout.php">登出</a></ul></div>
            </div>
            <div class ="CONTAINER">
                <div class="ck">
                <form action="updateintroduce_finish.php" method = "post">
                    <textarea class ="ckeditor" name="editor"> <?php  
                   error_reporting(E_ALL ^ E_DEPRECATED);

                   include("mysql_connect.inc.php");
                   $upnumber=$_SESSION['upnumber'];
                   
                   
                   $sql = "SELECT * FROM dramalist where dramanumber = '$upnumber'";
                   $result = mysql_query($sql);
                   while($row = mysql_fetch_array($result)){
                            $str = $row['introduce'];
                            echo $str;
                            //$_SESSION["gname"] = $row['groundname'];   
                        }     ?> 
                    </textarea>
                    <input type="submit" id="button" value="儲存" style="width:120px;height:40px;border:2px #FFCC22 dashed;background-color:#FFCC22;">
                   
                </form>
            </div>
            </div>
        </body>
</html>