<?php session_start();?>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);

include("mysql_connect.inc.php");
mysql_query("set names utf8");

$newdramaname=$_POST['newdramaname'];
$upnumber=$_SESSION['upnumber'];
$oldname=$_SESSION['oldname'];

//$query = mysqli_query($con,"INSERT INTO dramalist (dramaname,username,dramadate) VALUES ('$dramaname','$username','$dramadate')");
//插進去
if($newdramaname!=null){
$sql = "UPDATE dramalist SET dramaname = '$newdramaname' WHERE dramanumber = '$upnumber'";//插入表格語法
$sql2= "CREATE TABLE $newdramaname LIKE $oldname";
$sql3="INSERT INTO $newdramaname SELECT * FROM $oldname";
$sql4="drop table $oldname";
//mysqli_query($con, $query) or die("錯誤訊息：".mysqli_error($con));//執行插入
//echo "資料插入成功！";//顯示訊息null
//mysqli_close($con);
if(mysql_query($sql)&&mysql_query($sql2)&&mysql_query($sql3)&&mysql_query($sql4))
        {
            echo "<script>alert('修改成功!');history.go(-3)</script>";
        }
        else
        {
            echo "<script>alert('修改失敗!');history.go(-3)</script>";
        }


}
?>