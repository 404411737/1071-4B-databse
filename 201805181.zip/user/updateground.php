<?php session_start();?>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);

    include("mysql_connect.inc.php");
    mysql_query("set names utf8");
    //mysqli_query($link, 'SET CHARACTER SET utf8');
    //mysqli_query("SET collation_connection = 'utf8_general_ci'");
    $gnumber1= $_SESSION["gnumber"];
    $text=$_POST['editor'];
    //$gname1=$_SESSION["gname"];
    $dramaname2=$_SESSION["dramaname"];

    if($text!=null){
    $sql = "UPDATE $dramaname2 SET grounddrama = '$text' WHERE groundnumber = '$gnumber1'";
        if(mysql_query($sql))
        {
            //echo "ADDED INTO DB";
            //echo '<meta http-equiv=REFRESH CONTENT=2;url=page3.php>';
           echo "<script>alert('修改成功!');history.go(-2)</script>"; 
            unset($_SESSION["gnumber"]);
        }
        else
        {
            echo "ERROR WHILE INSERTING";
            //echo '<meta http-equiv=REFRESH CONTENT=2;url=page3.php >';
            echo "<script>alert('修改失敗 可憐!');history.go(-1)</script>";
            unset($_SESSION["gnumber"]);
            //$_SESSION['editor'];
        }
   }