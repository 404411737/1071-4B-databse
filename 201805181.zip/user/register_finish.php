<?php session_start(); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
include("mysql_connect.inc.php");

$id = $_POST['id'];
$pw = $_POST['pw'];
$pw2 = $_POST['pw2'];
$email1 = $_POST['email1'];
$other = $_POST['other'];
//判斷帳號密碼是否為空值
//確認密碼輸入的正確性
$sql = "SELECT * FROM member_table where username = '$id'";
$result = mysql_query($sql);
$row = @mysql_fetch_row($result);
if ($id != null && $row[0] == $id)
{
        echo '此帳號已有他人註冊，請使用另一帳號註冊!';
        echo '<meta http-equiv=REFRESH CONTENT=2;url=page1v3.html>';       
}
else if($id != null && $pw != null && $pw2 != null && $pw == $pw2 )
{
        //新增資料進資料庫語法
        $sql = "insert into member_table (username, password, email ,other) values ('$id', '$pw', '$email1', '$other')";
        if(mysql_query($sql))
        {
                echo '新增成功!';
                echo '<meta http-equiv=REFRESH CONTENT=2;url=page1v3.html>';

        }
        else
        {
                echo '新增失敗! 檢查有無缺少輸入';
                echo '<meta http-equiv=REFRESH CONTENT=2;url=page1v3.html>';
        }
}
 else if($id != null && $pw != null && $pw2 != null && $pw != $pw2){
        echo '新增失敗 密碼輸入不一致';
        echo '<meta http-equiv=REFRESH CONTENT=2;url=page1v3.html>';
           
}
else {
        echo '新增失敗';
        echo '<meta http-equiv=REFRESH CONTENT=2;url=page1v3.html>';
}
?>