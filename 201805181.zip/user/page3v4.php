<?php session_start();?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
    error_reporting(E_ALL ^ E_DEPRECATED);
    $dnumber=$_GET['dramastore'];
    $_SESSION["uploadnumber"]=$dnumber;
    //$_SESSION["dddd"]=$dnumber;
    include("mysql_connect.inc.php");
    $sql = "SELECT * FROM dramalist where dramanumber = '$dnumber'";
    $result = mysql_query($sql);
    while($row = mysql_fetch_array($result)){
        $name1 = $row['dramaname'];
        $_SESSION["dramaname"]=$name1;
    }
?>
<!DOCTYPE html>
    <html lang="en">
        <head>
            <title>實驗小劇場</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            <script>
               $("#progressbarTWInput").change(function(){
                readURL(this);
                });
              function readURL(input){
              if(input.files && input.files[0]){
              var reader = new FileReader();
              reader.onload = function (e) {
              $("#preview_progressbarTW_img").attr('src', e.target.result);
              }
              reader.readAsDataURL(input.files[0]);
              }
           }
           </script>
            <style>
                .navbar{
                    margin-bottom: 0;
                    border-radius: 0;
                    background-color: #F5F5F5;
                    padding: 1.0% 0;
                    font-size: 1.5em;
                    border: 0;
                }
                .navbar-brand{
                    float: left;
                    min-height: 65px;
                    padding: 0 15px 5px;
                }
                .navbar-default .navbar-bar .active a, .navbar-default .navbar-bar .active a:focus, .navbar-default .navbar-bar .active a:hover {
                     background-color: #F5F5F5;
                }
                footer{
                    height:15%;
                    width: 100%;
                    background-color: #F5F5F5;
                    padding: 2%;
                    right:0;
                    position:fixed;
                    bottom: 0px;
                }
                .main_container{
                    padding: 20px;
                    position:absolute;
                    height:80%;
                    width:70%;
                    top:10%;
                    right:0;
                
                }
                .btn-outline{
                    transition: all .5s;
                }
                .btn{
                    background-color: #32C7BF;
                    color: #F5F5F5;
                }
                .btn:focus,.btn.focus{
                    outline: 0;
                    background-color: #F5F5F5;
                    color: #32C7BF;
                }
                .btn:hover{
                    border-color: #32C7BF;
                    background-color: #F5F5F5;
                    color: #32C7BF;
                }
                .sceneBtn{
                    margin: 15px;
                    height: 100px;
                    min-width: 100px;
                    max-width: 100px;
                }
                 #modalTile{
                    font-size: 18px;
                    font-family: "Helvetica Neue","Arial",sans-serif;
                }
                #scenesNum{
                    resize: none;
                    width: 100%;
                }
                .vertical-align-center{
                    display: table-cell;
                    vertical-align: middle;
                }
                .main_timeliner{
                    background-color: bisque;
                    z-index: 1;
                    float: left;
                    height: 90%;
                    width: 30%;
                    top:10%;
                    padding: 0.8% 0.8%;  
                    overflow-y:scroll;
                }
                #bar{
                    position: relative;
                    display: inline-block;
                    width: 10px;
                    height: 100%;
                    border: 10px solid rgba(255,0,0,3);
                }     
                .info1{
                    height: 100%;
                    width: 8%;
                    float: left;
                }
                .info2{
                    margin: 20px;
                    height: 15%;
                    width: 90%;
                    position: relative;
                    left:3%;
                    background-color: cornsilk;  
                }
            </style>
            
        </head>
        <body>
            <nav class="navbar navbar-default">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span> 
                        </button>
                        <a class="navbar-brand" href="page1v3.php"><img src="logoX.png"></a>
                    </div>
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav navbar-right">
                             <button type="button" class="btn btn-outline navbar-btn btn-lg" onclick="self.location.href='imagejcrop.php'">
                            上傳劇本預覽圖片
                            </button>
                            <button type="button" class="btn btn-outline navbar-btn btn-lg" data-toggle="modal" data-target="#addSecnes">
                                新增場景
                            </button>
                            <button class="btn btn-outline navbar-btn btn-lg" onclick="self.location.href='logout.php'">登出</button>
                        </ul>
                    </div>
                </div>
            </nav>
            <div class="main_timeliner">
                <div class="info1">
                    <i id="bar"></i>
                </div>
                <?php
                    error_reporting(E_ALL ^ E_DEPRECATED);
                    $db_server = "localhost";
                    $db_name = "mydb";
                    $db_user = "root";
                    $db_passwd = "1234";
                    $con = mysql_connect($db_server, $db_user, $db_passwd);
                    mysql_query("SET NAMES 'utf8'");
                    mysql_select_db($db_name);
                    
                    $sql2 = "SELECT * FROM $name1";
                    $result = mysql_query($sql2);
                    while($row = mysql_fetch_array($result)){
                        $str = $row['groundname'];
                        $gnumber = $row['groundnumber'];
                        echo "<div class='info2'><a href=page3.php?groundstore=".$gnumber."> $str <br></a></div>";
                    }        
                ?>  
            </div>
            <div class="main_container" style="overflow-y:scroll  ">
                <?php
                    error_reporting(E_ALL ^ E_DEPRECATED);
                    $db_server = "localhost";
                    $db_name = "mydb";
                    $db_user = "root";
                    $db_passwd = "1234";
                    $con = mysql_connect($db_server, $db_user, $db_passwd);
                    mysql_query("SET NAMES 'utf8'");
                    mysql_select_db($db_name);
                    $sql = " SELECT * FROM $name1";
                    $result = mysql_query($sql);
                    while($row = mysql_fetch_array($result)){
                        $str = $row['grounddrama'];
                        echo  $str  ;
                        echo "<br />========================================";
                    }        
                ?>
                <div class="modal fade" id="addSecnes" tabindex="-1" role="dialog" aria-labelledby="modalTile" aria-hidden="true" >
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content" >
                            <form class="ground" name="cut" method="post" action="addgroundnum.php">
                                <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <p class="modal-title" id="modalTile">How many scenes do you want to add ?</p>
                                </div>
                                <div class="modal-body">
                                    <textarea type="gnumber" name="gnum" id="scenesNum"></textarea>
                                </div>
                                <div class="modal-footer">
                                    <input class="btn btn-light" type="submit" value="ENTER">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </body>
    </html>