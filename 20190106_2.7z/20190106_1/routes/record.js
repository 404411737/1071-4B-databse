var express = require('express');
var router = express.Router();

const recordController = require('../controllers/record');

router.get('/',recordController.getRecord);
router.get('/add',recordController.postAddRecord);
router.get('/delete',recordController.getDeleteRecord);
router.get('/update',recordController.postUpdateRecord);

module.exports = router;