const moment = require('moment');

const Account = require('../models/account');

//READ
exports.getAccount = (req, res, next) => {
    Account.fetchAll()
        .then(([rows]) => {
            //console.log(JSON.stringify(rows));
            res.send(JSON.stringify(rows));
            res.render('account', {
                data: rows,
                title: 'List',
            });
        })
        .catch(err => console.log(err));
};

//ADD
exports.postAddAccount = (req, res, next) => {
    Account.add(req, res)
        .then(([rows]) => {
            res.redirect('/account');
        })
        .catch(err => console.log(err));
};

//DELETE
exports.getDeleteAccount = (req, res, next) => {
    Account.deleteById(req.query.UID)
        .then(([rows]) => {
            res.redirect('/account');
        })
    .catch();
};

//UPDATE
exports.postUpdateAccount = (req, res, next) => {
    Account.updateById(req, res)
        .then(([rows]) => {
            res.redirect('/account');
        })
        .catch(err => console.log(err));
};