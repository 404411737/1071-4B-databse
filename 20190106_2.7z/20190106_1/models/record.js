const db = require('../util/database');

module.exports = class Record {

    constructor(rID,rUser,rVideo,rMethod,rPrice,rDate,rDay) {
        this.rID = rID;
        this.rUser = rUser;
        this.rVideo = rVideo;
        this.rMethod = rMethod;
        this.rPrice = rPrice;
        this.rDate = rDate;
        this.rDay = rDay;
    }

    // READ
    static fetchAll() {
        return db.execute('SELECT * FROM record');
    }

    //ADD
    static add(req, res) {
        return db.execute(
          'INSERT INTO record (rID,rUser,rVideo,rMethod,rPrice,rDate,rDay) VALUES (?,?,?,?,?,?,?)',
          [req.body.rID, req.body.rUser, req.body.rVideo, req.body.rMethod, req.body.rPrice, req.body.rDate, req.body.rDay]
        );
    }

    //DELETE
    static deleteById(rID) {
        return db.execute(
        'DELETE FROM record WHERE rID = ?', [rID]
        );
    }

    //UPDATE
    static updateById(req, res) {
        this.rID = req.body.rID;
        this.rUser = req.body.rUser;
        this.rVideo = req.body.rVideo;
        this.rMethod = req.body.rMethod;
        this.rPrice = req.body.rPrice;
        this.rDate = req.body.rDate;
        this.rDay = req.body.rDay;

        return db.execute(
          'UPDATE record SET rUser = ?, rVdieo = ?, rMethod = ?, rPrice = ? ,rDate = ? ,rDay = ? WHERE rID = ?', [rID,rUser,rVideo,rMethod,rPrice,rDate,rDay]
        );
      }
}